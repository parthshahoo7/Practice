package org.cap.wallet.dao;

import java.util.List;

import org.cap.wallet.model.Account;

public interface IAccountDao {

	public Account createAccount(Account account);

	public Account searchAccount(String id);

	public Account updateAccount(Account account);

	public int generateAccountId();

}
