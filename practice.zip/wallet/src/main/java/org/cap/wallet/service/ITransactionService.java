package org.cap.wallet.service;

import java.util.List;

import org.cap.wallet.model.Transactions;

public interface ITransactionService {

	public Transactions addTransaction(Transactions transactions);

	public List<Transactions> viewAllTransactions(String accountid);

}
