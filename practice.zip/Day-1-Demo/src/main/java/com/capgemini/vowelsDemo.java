package com.capgemini;

public class vowelsDemo {
	private int a = 0, e = 0, i = 0, o = 0, u = 0;

	public void displayNumberofVovels() {
		System.out.println("a:" + a);
		System.out.println("e:" + e);
		System.out.println("i:" + i);
		System.out.println("o:" + o);
		System.out.println("u:" + u);

	}

	public void participateVovels(String string) {
		char[] str = string.toCharArray();
		for (int k = 0; k < str.length; k++) {
			switch (str[k]) {
			case 'a':
				a++;
				break;
			case 'e':
				e++;
				break;
			case 'i':
				i++;
				break;
			case 'o':
				o++;
				break;
			case 'u':
				u++;
				break;

			default:
				break;
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String string = "welcome to java program!";
		vowelsDemo vd = new vowelsDemo();
		vd.participateVovels(string);
		vd.displayNumberofVovels();
	}

}
