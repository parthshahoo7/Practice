package org.cap.controller.byme;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {

	@RequestMapping("/hello")
	public ModelAndView greetUser() {
		String msg = "Hello User!";
		/*
		 * greetpage-->viewObjectName, message--> modelobjectName, msg-->ModelObject
		 */
		return new ModelAndView("greetPage", "message", msg);
	}
}
