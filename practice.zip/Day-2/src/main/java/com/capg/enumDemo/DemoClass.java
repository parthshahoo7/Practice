package com.capg.enumDemo;

public class DemoClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Weekdays day = Weekdays.FIR;
		System.out.println(day);
		System.out.println(day.name());
		System.out.println(day.getValue());

		Weekdays[] days = Weekdays.values();
		for (Weekdays da : days) {
			System.out.print(da + ",");
		}

		CustomerType[] customers = CustomerType.values();
		for (CustomerType cust : customers) {
			System.out.println(cust + "" + cust.getMaxValue() + "" + cust.getMinValue());
		}
	}

}
