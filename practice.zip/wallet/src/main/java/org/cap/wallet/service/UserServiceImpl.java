package org.cap.wallet.service;

import java.util.concurrent.atomic.AtomicInteger;

import org.cap.wallet.dao.IUserDao;
import org.cap.wallet.dao.UserDaoImpl;
import org.cap.wallet.model.User;

public class UserServiceImpl implements IUserService {

	private IUserDao dao = new UserDaoImpl();
	private static final AtomicInteger count = new AtomicInteger(1000);

	/*
	 * private String getUserId() { int id = 0; String account_id = "wallet"; id =
	 * count.incrementAndGet(); // TODO Auto-generated method stub return
	 * (account_id + id); }
	 */
	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		// user.setUserId(getUserId());
		return dao.addUser(user);
	}

	@Override
	public User searchUser(String userId) {
		// TODO Auto-generated method stub
		return dao.searchUser(userId);
	}

	@Override
	public User loginUser(String emailId, String password) {
		// TODO Auto-generated method stub
		return dao.loginUser(emailId, password);
	}

}
