package com.capg;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserInteractions ui = new UserInteractions();
		Employee employee = ui.getEmployeeDetails();
		System.out.println(employee.getEmployeeId());
		System.out.println(employee.getFirstName());
		System.out.println(employee.getLastName());
		System.out.println(employee.getSalary());
		System.out.println(employee.getEmailId());
		System.out.println(employee.getEmployeeType());

		System.out.println(employee.getAddress().getDoorNo());
		System.out.println(employee.getAddress().getStreetName());
		System.out.println(employee.getAddress().getCity());
		System.out.println(employee.getAddress().getState());
		System.out.println(employee.getAddress().getPincode());
		System.out.println("-----------------------");
		System.out.println(employee.toString());
	}

}
