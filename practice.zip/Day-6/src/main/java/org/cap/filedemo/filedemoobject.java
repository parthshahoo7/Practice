package org.cap.filedemo;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class filedemoobject {
	public static void main(String[] args) {
		// ArrayList<filedatainputstreademo> data = new
		// ArrayList<filedatainputstreademo>();
		Scanner sc = new Scanner(System.in);
		filedatainputstreademo fdemo = new filedatainputstreademo();
		try (FileOutputStream fout = new FileOutputStream(
				"C:\\Users\\partshah\\OneDrive - Capgemini\\Desktop\\demo\\des.txt");
				ObjectOutputStream dout = new ObjectOutputStream(fout);) {
			System.out.println("Enter Emp ID:");
			fdemo.setEmployeeid(sc.nextInt());
			System.out.println("Enter Gender:");
			fdemo.setGender(sc.next().charAt(0));
			System.out.println("Enter Salary:");
			fdemo.setSalary(sc.nextDouble());
			System.out.println("Enter Emp name:");
			fdemo.setName(sc.next());
			fdemo.setLengthofname(fdemo.getName().length());
			dout.writeObject(fdemo);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try (FileInputStream fin = new FileInputStream(
				"C:\\\\Users\\\\partshah\\\\OneDrive - Capgemini\\\\Desktop\\\\demo\\\\des.txt");
				ObjectInputStream di = new ObjectInputStream(fin);) {

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
