package org.cap.employee.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.cap.employee.Employee;

public class EmployeeDaoImpl implements IEmplyeeDao {

	private Connection getDBConnection() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		String url = "jdbc:mysql://localhost:3306/capgedbs";
		Connection connection = DriverManager.getConnection(url, "root", "1234");
		return connection;

	}

	@Override
	public Employee addEmployee(Employee employee) {
		try (Connection connection = getDBConnection();) {
			String sql = "insert into employee values(?,?,?,?,?,?)";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, employee.getEmployeeId());
			preparedStatement.setString(2, employee.getFname());
			preparedStatement.setString(3, employee.getLname());
			preparedStatement.setDouble(4, employee.getSalary());
			preparedStatement.setBoolean(5, employee.isPermenant());
			preparedStatement.setDate(6, employee.getDateofJoining());
			int count = preparedStatement.executeUpdate();

			if (count > 0) {
				return employee;
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	// TODO Auto-generated method stub }

	@Override
	public Employee findEmployee(int employeeId) {
		// TODO Auto-generated method stub
		Employee employee = new Employee();
		try (Connection connection = getDBConnection()) {
			String sql = "select * from employee where employeeid=?";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, employeeId);
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				employee.setEmployeeId(resultSet.getInt(1));
				employee.setFname(resultSet.getString(2));
				employee.setLname(resultSet.getString(3));
				employee.setSalary(resultSet.getDouble(4));
				employee.setPermenant(resultSet.getBoolean(5));
				employee.setDateofJoining(resultSet.getDate(6));
			}
			return employee;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return employee;
	}

	@Override
	public boolean deleteEmployee(int employeeId) {
		// TODO Auto-generated method stub
		try (Connection connection = getDBConnection()) {
			String sql = "delete from employee where employeeid=?";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, employeeId);
			int count = preparedStatement.executeUpdate();
			if (count > 0) {
				return true;
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public Employee UpdateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		// Employee employee = new Employee();
		try (Connection connection = getDBConnection()) {
			String sql = "update employee set fname=?,lname=?,salary=? where employeeid=?";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, employee.getFname());
			preparedStatement.setString(2, employee.getLname());
			preparedStatement.setDouble(3, employee.getSalary());
			preparedStatement.setInt(4, employee.getEmployeeId());
			int count = preparedStatement.executeUpdate();
			if (count > 0) {
				return employee;
			}
			return employee;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Employee> viewAllEmploees() {
		// TODO Auto-generated method stub
		ArrayList<Employee> employees = new ArrayList<Employee>();
		try (Connection connection = getDBConnection();) {
			String sql = "select * from employee";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				Employee employee = new Employee();
				employee.setEmployeeId(resultSet.getInt(1));
				employee.setFname(resultSet.getString(2));
				employee.setLname(resultSet.getString(3));
				employee.setSalary(resultSet.getDouble(4));
				employee.setPermenant(resultSet.getBoolean(5));
				employee.setDateofJoining(resultSet.getDate(6));
				employees.add(employee);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return employees;
	}

	@Override
	public int sumArray(int[] arr) {
		// TODO Auto-generated method stub
		int sum = 0;
		for (int n : arr)
			sum += n;
		return sum;
	}

}
