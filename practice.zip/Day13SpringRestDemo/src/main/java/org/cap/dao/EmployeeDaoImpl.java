package org.cap.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.cap.model.Address;
import org.cap.model.Employee;
import org.springframework.stereotype.Repository;

@Repository("employeeDao")
public class EmployeeDaoImpl implements IEmployeeDao {

	private static List<Employee> employees = dumyDB();

	private static List<Employee> dumyDB() {
		List<Employee> employees = new ArrayList<Employee>();
		employees.add(new Employee(32, "tom", "jerry", new Date(2019 - 1900, 1, 21), new Date(2019 - 1900, 1, 21),
				new Address(21, "dad", "asd", "sdf", 1231, "dsv"), 2300));
		employees.add(new Employee(232, "tom", "jerry", new Date(2019 - 1900, 1, 21), new Date(2019 - 1900, 1, 21),
				new Address(212, "dad", "asd", "sdf", 1231, "dsv"), 2300));
		employees.add(new Employee(5, "tom", "jerry", new Date(2019 - 1900, 1, 21), new Date(2019 - 1900, 1, 21),
				new Address(2211, "dad", "asd", "sdf", 1231, "dsv"), 2300));
		return employees;
	}

	@Override
	public List<Employee> getEmployees() {
		// TODO Auto-generated method stub
		return employees;
	}

	@Override
	public Employee findEmployee(Integer empID) {
		// TODO Auto-generated method stub
		for (Employee emp : employees) {
			if (emp.getEmployeeID() == empID) {
				return emp;
			}
		}
		return null;
	}

	@Override
	public List<Employee> deleteEmployee(Integer empID) {
		// TODO Auto-generated method stub
		boolean flag = false;
		Iterator<Employee> iterator = employees.iterator();
		while (iterator.hasNext()) {
			Employee employee = iterator.next();
			if (employee.getEmployeeID() == empID) {
				iterator.remove();
				flag = true;
			}
		}
		if (flag)
			return employees;
		return null;
	}

	@Override
	public List<Employee> createEmployee(Employee employee) {
		// TODO Auto-generated method stub
		employees.add(employee);
		return employees;
	}

	@Override
	public List<Employee> updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		boolean flag = false;
		ListIterator<Employee> iterator = employees.listIterator();
		while (iterator.hasNext()) {
			Employee emp = iterator.next();
			if (emp.getEmployeeID() == employee.getEmployeeID()) {
				flag = true;
				iterator.set(employee);
			}
		}
		if (flag)
			return employees;
		return null;
	}

	@Override
	public List<Employee> partiallyUpdateEmployee(Integer empID, String firstName) {
		boolean flag = false;
		ListIterator<Employee> iterator = employees.listIterator();
		while (iterator.hasNext()) {
			Employee emp = iterator.next();
			if (emp.getEmployeeID() == empID) {
				flag = true;
				emp.setFirstName(firstName);
				iterator.set(emp);
			}
		}
		if (flag)
			return employees;
		return null;
	}

}
