import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/capgedbs";
			Connection connection = DriverManager.getConnection(url, "root", "1234");
			if (connection != null) {
				Statement statement = connection.createStatement();
				/*
				 * // Table creation
				 * 
				 * String sql = "create table employee(employeeid int primary key," +
				 * "firstname varchar(50),lastname varchar(50)," + "salary numeric(8,2))";
				 * boolean query = statement.execute(sql); if (!query) {
				 * System.out.println("Table Created"); } else {
				 * System.out.println("Sorry There is an Error!"); }
				 * 
				 * // Table Deletion
				 * 
				 * String delsql = "drop table employee"; boolean query1 =
				 * statement.execute(delsql); if (!query1) {
				 * System.out.println("Table Successfully deleted!"); } else {
				 * System.out.println("Sorry! There is an Error."); }
				 * 
				 * // Table Manipulation
				 * 
				 * String insertSql = "insert into employee values(123,'tom','jerry',23000)";
				 * int count = statement.executeUpdate(insertSql); if (count > 0) {
				 * System.out.println("Record inserted ssuccessfully!"); } else {
				 * System.out.println("Sorry! There is an error in your query!"); }
				 * 
				 * 
				 * // prepared statedments
				 * 
				 * String fname = "klfm"; String lname = "fvsfv"; double salary = 32232; int
				 * empid = 124; String presql = "insert into employee values(?,?,?,?)"; //
				 * String presql = "update employee set lastname=?,salary=? where employeeid=?";
				 * 
				 * String presql = "delete from employee where employeeid=?"; PreparedStatement
				 * pst = connection.prepareStatement(presql); pst.setInt(1, empid); //
				 * pst.setString(1, lname); // pst.setDouble(2, salary); // pst.setInt(3,
				 * empid);
				 * 
				 * pst.setInt(1, empid); pst.setString(2, fname); pst.setString(3, lname);
				 * pst.setDouble(4, salary);
				 * 
				 * int count = pst.executeUpdate(); if (count > 0) {
				 * System.out.println("Record inserted ssuccessfully!"); } else {
				 * System.out.println("Sorry! There is an error in your query!"); }
				 * 
				 * // DQL // String sql = "select * from employee"; // String sql =
				 * "select * from employee where salary>?"; // PreparedStatement
				 * preparedStatement = connection.prepareStatement(sql); //
				 * preparedStatement.setDouble(1, 300000); // ResultSet resultSet =
				 * preparedStatement.executeQuery(); // while (resultSet.next()) { //
				 * System.out.println(resultSet.getInt(1) + "\t" + resultSet.getString(2) + "\t"
				 * // + resultSet.getString(3) + "\t" + resultSet.getDouble(4)); // }
				 * 
				 * String complexQuery = "select * from employee where salary > " + "";
				 * 
				 * // System.out.println("Database Connection Succssfully received..");
				 */
				

			} else {
				System.out.println("Sorry! Connection Error.");
			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
