package com.cap.generics;

import java.util.ArrayList;
import java.util.List;

import com.cap.employee.Director;
import com.cap.employee.Employee;
import com.cap.employee.Test;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Sender<String> msg = new Sender<String>("klsdnmvsdnvkln");
//		System.out.println(msg.getMessage());
//		Sender<Employee> empSender = new Sender<Employee>(new Employee(10, "ckldnc", "jkcnen", 12.12));
//		System.out.println(empSender.getMessage());

//		Sender<Director, Employee> msg = new Sender<Director, Employee>();
//		msg.setMessage(new Director(1, "csdnkcl", "cdd", 12.23, "ianca", "Manager"));
//		msg.setNewmessage(new Employee(10, "ckldnc", "jkcnen", 12.12));
//		System.out.println(msg.getMessage());
//		System.out.println(msg.getNewmessage());

		List<Integer> values = new ArrayList<Integer>();
		values.add(12);
		values.add(13);
		values.add(45);
		values.add(10);
		values.add(9);
		Test.sum(values);
		values.add(78);
		List<String> values1 = new ArrayList<String>();
		values1.add("cjdncsj");
		values1.add("cjdncsj");
		values1.add("cjdncsj");
		values1.add("cjdncsj");
		values1.add("cjdncsj");
		values1.add("cjdncsj");
		values1.add("cjdncsj");
		values1.add("cjdncsj");
		Test.sum(values1);
		Employee e1 = new Employee(10, "ckldnc", "jkcnen", 12.12);
		List<Employee> values2 = new ArrayList<Employee>();
		Director d1 = new Director(10, "ckldnc", "jkcnen", 12.12, "vsrvion");
		List<Director> values3 = new ArrayList<Director>();
		values2.add(d1);
		Test test = new Test();
		test.display(values2);
	}

}
