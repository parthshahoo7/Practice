package com.cap.util;

import java.util.Comparator;

import com.cap.model.Customer;

public class SortDataByLastName implements Comparator<Customer> {

	@Override
	public int compare(Customer o1, Customer o2) {
		// TODO Auto-generated method stub
		return o1.getLastName().compareTo(o2.getLastName());
	}

}
