package org.cap.demo.hasa;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Address {
	@Id
	@GeneratedValue
	private int addressId;
	private String addressLine;

	@OneToOne
	@JoinColumn(name = "employeeId")
	private Employee employee;

	public Address(int addressId, String addressLine, Employee employee) {
		super();
		this.addressId = addressId;
		this.addressLine = addressLine;
		this.employee = employee;
	}

	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Address(int addressId, String addressLine) {
		super();
		this.addressId = addressId;
		this.addressLine = addressLine;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getAddressLine() {
		return addressLine;
	}

	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", addressLine=" + addressLine + "]";
	}

}
