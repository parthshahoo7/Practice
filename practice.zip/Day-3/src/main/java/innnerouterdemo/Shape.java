package innnerouterdemo;

public interface Shape {

	public void draw();

	public interface Color {
		void fillColor();
	}

}
