package com.cap.test.pom;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cap.model.pom.SignupPage;

public class TestSignUpPage {
	WebDriver driver = null;

	@Before
	public void before() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://localhost:8080/SeleniumDynamicProjectDemo/sign_up.html");
	}

	@Test
	public void testSignUp() throws InterruptedException {
		try {
			SignupPage signupPage = new SignupPage(driver);
			signupPage.signUpWithData("parth", "parth123", "parth@123");
		} catch (NullPointerException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	@After
	public void after() {
		driver.quit();
	}
}
