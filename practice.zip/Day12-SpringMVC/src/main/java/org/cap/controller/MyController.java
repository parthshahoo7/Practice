package org.cap.controller;

import java.util.ArrayList;
import java.util.List;

import org.cap.model.User;
import org.cap.model.UserLogin;
import org.cap.service.ILoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
//@RequestMapping("/v1")
public class MyController {
	
	@Autowired
	private ILoginService loginService;
	
	@RequestMapping(value="/saveRegistration",method = RequestMethod.POST)
	public String registerUser(@ModelAttribute("user")User user) {
		System.out.println(user);
		return "success";
	}
	
	
	
	@RequestMapping("/register")
	public String getRegistrationPage(ModelMap map) {
		
	
		
		map.put("user",new User());
		map.put("cities",getCities());
		map.put("states",getStates());
		map.put("countries",getCountries());
		return "register";
	}
	
	
	private List<String> getCountries(){
		List<String> countries=new ArrayList<String>();
		countries.add("USA");
		countries.add("UK");
		countries.add("India");
		countries.add("Australia");
		countries.add("Germen");
		return countries;
	}
	
	
	private List<String> getCities(){
		List<String> cities=new ArrayList<String>();
		cities.add("Rosemont");
		cities.add("Chicago");
		cities.add("Lake");
		cities.add("Clark");
		cities.add("Washington");
		cities.add("NewYork");
		return cities;
	}
	
	private List<String> getStates(){
		List<String> states=new ArrayList<String>();
		states.add("IL");
		states.add("NA");
		states.add("NY");
		states.add("NC");
		states.add("SK");
		states.add("CP");
		return states;
	}
	
	
	@RequestMapping(value="/validateLogin",method = RequestMethod.POST)
	public String validateUserLogin(
			@RequestParam("userName")String userName,
			@RequestParam("userPwd")String userPwd,
			ModelMap map) {
		
		UserLogin login=new UserLogin();
		login.setUserName(userName);
		login.setUserPassword(userPwd);
		
		if(loginService.isValidLogin(login)) {
			map.put("user", userName);
			map.put("msg","Congras! You Done!");
			return "mainPage";
		}else
		{
			//map.put("errMsg","Sorry! Invalid Login!");
			return "redirect:/";
		}
	}
	

	
	@RequestMapping("/hello")
	public ModelAndView greetUser() {
		String msg="Hello! Good Morning EveryBody!";
		/*
		 * greetpage --> viewObjectName, message --> modelObjectName,
		 *  msg-->Model Object
		 */
		return new ModelAndView("greetPage", "message", msg);
	}
	
	
}
