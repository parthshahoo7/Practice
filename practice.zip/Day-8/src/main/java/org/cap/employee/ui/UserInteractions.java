package org.cap.employee.ui;

import java.sql.Date;
import java.util.Scanner;

import org.cap.employee.Employee;

public class UserInteractions {
	Scanner sc = new Scanner(System.in);

	public int display() {
		int choice = 0;
		System.out.println("Employee Portal:");
		System.out.println("1. Add Employee");
		System.out.println("2. Find Employee");
		System.out.println("3. Delete Employee");
		System.out.println("4. Update Employee");
		System.out.println("5. List All Employee");
		System.out.println("6. Exit");
		choice = sc.nextInt();
		return choice;
	}

	public Employee addEmployee() {
		System.out.println("Enter Employee Id:");
		int id = sc.nextInt();
		System.out.println("Enter FirstName:");
		String fname = sc.next();
		System.out.println("Enter LastName:");
		String lname = sc.next();
		System.out.println("Enter Salary:");
		double salary = sc.nextShort();
		System.out.println("Are you permenent employee? (true/false) ");
		boolean ispermenent = sc.nextBoolean();
		System.out.println("Enter Date of Joining: (YYYY-mm-dd)");
		String date = sc.next();
		Date mydate = Date.valueOf(date);
		Employee employee = new Employee(id, fname, lname, salary, ispermenent, mydate);
		return employee;
	}

	public int getEmployeeId() {
		System.out.println("Enter Employee Id:");
		int id = sc.nextInt();
		return id;
	}

	public int updateEmployeeMenu() {
		System.out.println("Select one of the following to update!");
		System.out.println("1. First Name");
		System.out.println("2. Last Name");
		System.out.println("3. Salary");
		int choice = sc.nextInt();
		return choice;

	}

	public Employee updateEmployeebyFirstName(Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}
}
