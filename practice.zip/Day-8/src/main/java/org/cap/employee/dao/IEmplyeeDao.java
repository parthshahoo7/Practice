package org.cap.employee.dao;

import java.util.List;

import org.cap.employee.Employee;

public interface IEmplyeeDao {
	public Employee addEmployee(Employee employee);

	public Employee findEmployee(int employeeId);

	public boolean deleteEmployee(int employeeId);

	public Employee UpdateEmployee(Employee employee);

	public List<Employee> viewAllEmploees();

	public int sumArray(int[] arr);
}
