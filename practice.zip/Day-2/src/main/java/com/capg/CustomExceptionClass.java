package com.capg;

public class CustomExceptionClass extends Exception {

	public CustomExceptionClass() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "Sorry! Salary must be between 2000 to 10000.";
	}

}
