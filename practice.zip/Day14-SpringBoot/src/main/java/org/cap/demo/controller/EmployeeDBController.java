package org.cap.demo.controller;

import java.util.List;

import org.cap.demo.dao.IEmployeeDao;
import org.cap.demo.model.Employee;
import org.cap.demo.service.IDbEmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v2")
public class EmployeeDBController {

	@Autowired
	private IDbEmployeeService employeeDBService;

	@GetMapping("/employees/{empID}")
	public ResponseEntity<Employee> findEmployee(@PathVariable("empID") Integer empID) {
		Employee employee = employeeDBService.findEmployee(empID);

		if (employee == null)
			return new ResponseEntity("Sorry! Employee Not Found!!", HttpStatus.NOT_FOUND);

		return new ResponseEntity<Employee>(employee, HttpStatus.OK);
	}

	@GetMapping("/employees")
	public ResponseEntity<List<Employee>> getAllEmployees() {
		List<Employee> employees = employeeDBService.getAllEmployee();
		if (employees.isEmpty())
			return new ResponseEntity("Sorry! Employee Not Available!", HttpStatus.NOT_FOUND);

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@DeleteMapping("/employees/{empId}")
	public ResponseEntity<List<Employee>> deleteEmployees(@PathVariable("empId") Integer empId) {
		List<Employee> employees = employeeDBService.deleteEmployee(empId);
		if (employees == null || employees.isEmpty())
			return new ResponseEntity("Sorry! EmployeeId Not Found!", HttpStatus.NOT_FOUND);

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@PostMapping("/employees")
	public ResponseEntity<List<Employee>> createEmployees(@RequestBody Employee employee) {
		List<Employee> employees = employeeDBService.createEmployee(employee);

		if (employees == null || employees.isEmpty())
			return new ResponseEntity("Sorry! EmployeeId Not Found!", HttpStatus.NOT_FOUND);

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@PutMapping("/employees")
	public ResponseEntity<List<Employee>> updateEmployees(@RequestBody Employee employee) {
		List<Employee> employees = employeeDBService.updateEmployee(employee);

		if (employees == null || employees.isEmpty())
			return new ResponseEntity("Sorry! EmployeeId Not Found!", HttpStatus.NOT_FOUND);

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@PatchMapping("/employees/{empId}/{firstName}")
	public ResponseEntity<List<Employee>> partialUpdateEmployees(@PathVariable("empId") Integer empId,
			@PathVariable("firstName") String firstName) {
		List<Employee> employees = employeeDBService.updateEmployeeFirstName(empId, firstName);

		if (employees == null || employees.isEmpty())
			return new ResponseEntity("Sorry! EmployeeId Not Found!", HttpStatus.NOT_FOUND);

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

}
