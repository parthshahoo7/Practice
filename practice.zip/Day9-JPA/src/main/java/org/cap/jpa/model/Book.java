package org.cap.jpa.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Book {
	@Id
	private BookId bookId;
	/*
	 * @Id private int bookid;
	 * 
	 * @Id private int publishedId;
	 */
	private String bookName;

	public Book(BookId bookId, String bookName) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
	}

	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}

	/*
	 * public Book(int bookid, int publishedId, String bookName) { super();
	 * this.bookid = bookid; this.publishedId = publishedId; this.bookName =
	 * bookName; }
	 */

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public BookId getBookId() {
		return bookId;
	}

	public void setBookId(BookId bookId) {
		this.bookId = bookId;
	}

	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookName=" + bookName + "]";
	}

}
