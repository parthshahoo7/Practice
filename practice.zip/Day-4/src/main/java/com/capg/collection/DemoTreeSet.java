package com.capg.collection;

import java.util.Iterator;
import java.util.TreeSet;

public abstract class DemoTreeSet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<Integer> treeSet = new TreeSet<Integer>();
		treeSet.add(23);
		treeSet.add(2);
		treeSet.add(10);
		treeSet.add(99);
		treeSet.add(87);
		treeSet.add(0);
		treeSet.add(87);
		treeSet.add(0);
		// treeSet.add(null); It doesnot accept null value
		Iterator<Integer> iterator = treeSet.iterator();
		while (iterator.hasNext()) {
			System.out.print(iterator.next() + ",");
		}

	}

}
