package org.cap.wallet.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.wallet.model.User;
import org.cap.wallet.service.IUserService;
import org.cap.wallet.service.UserServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet({ "/LoginServlet", "/login" })
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		IUserService userService = new UserServiceImpl();
		PrintWriter printWriter = response.getWriter();

		String email = request.getParameter("emailid");
		String password = request.getParameter("password");

		User login = new User();
		login.setEmailId(email);
		login.setPassword(password);

		User validUser = userService.loginUser(login.getEmailId(), login.getPassword());
		if (validUser != null) {
			HttpSession session = request.getSession();
			session.setAttribute("userid", validUser.getUserId());
			session.setAttribute("user", validUser);
			response.sendRedirect("main");
		} else {
			request.getRequestDispatcher("index.html").include(request, response);
			printWriter.println("<h1>Sorry! Invalid Credantials!</h1>");
		}

	}

}
