package com.cap.stepdefinitions;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SignUpStepDefinitions {
	WebDriver driver = new ChromeDriver();

	@Given("^user is on sign up page$")
	public void user_is_on_sign_up_page() throws Throwable {
		driver.manage().window().maximize();
		driver.get("http://localhost:8080/SeleniumDynamicProjectDemo/sign_up.html");
	}

	@When("^user enters data given in all the fields$")
	public void user_enters_data_given_in_all_the_fields(DataTable arg1) throws Throwable {
		List<String> list = arg1.asList(String.class);
		Thread.sleep(2000);
		driver.findElement(By.id("username")).sendKeys(list.get(0));
		Thread.sleep(2000);
		driver.findElement(By.id("password")).sendKeys(list.get(1));
		Thread.sleep(2000);
		driver.findElement(By.id("confirmpassword")).sendKeys(list.get(2));
		Thread.sleep(2000);
		new Select(driver.findElement(By.id("country"))).selectByValue("usa");
		Thread.sleep(2000);
		driver.findElement(By.name("gender")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("tc")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("signup")).click();
		Thread.sleep(2000);
		Alert popup = driver.switchTo().alert();
		popup.accept();
		Thread.sleep(2000);
		Alert alert = driver.switchTo().alert();
		alert.accept();
		Thread.sleep(2000);
	}

	@Then("^user navigated to login page$")
	public void user_navigated_to_login_page() throws Throwable {
		driver.quit();
	}

}
