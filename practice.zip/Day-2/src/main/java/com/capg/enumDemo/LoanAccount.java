package com.capg.enumDemo;

public class LoanAccount {

	private enum LoanType {
		CAR, EDUCATIONAL, HOME;

		private enum HomeLoan {
			Home, Appartment;
		}
	}

	private String accountNo = "";
	private String accountName = "Tom Jerry";
	private LoanType loanType = LoanType.CAR;
	private LoanType.HomeLoan home = LoanType.HomeLoan.Home;
}
