package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.cap.model.UserLogin;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("loginDao")
//@Transactional
public class LoginDaoImpl implements ILoginDao{

	@PersistenceContext
	private EntityManager entityManager;
	
	
	@Transactional
	@Override
	public boolean isValidLogin(UserLogin userLogin) {
		Query query= entityManager
			.createQuery("from UserLogin user where "
					+ "user.userName=:userName and user.userPassword=:userPwd");
		
		query.setParameter("userName", userLogin.getUserName());
		query.setParameter("userPwd", userLogin.getUserPassword());
		
		List<UserLogin> logins= query.getResultList();
		
		if(logins.size()>0)
			return true;
		
		return false;
	}

}
