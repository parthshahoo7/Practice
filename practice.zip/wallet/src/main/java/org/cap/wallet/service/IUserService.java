package org.cap.wallet.service;

import org.cap.wallet.model.User;

public interface IUserService {
	public User addUser(User user);

	public User searchUser(String userId);

	public User loginUser(String emailId, String password);
}
