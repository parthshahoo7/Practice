package org.cap.wallet.service;

import java.util.List;

import org.cap.wallet.model.Account;

public interface IAccountService {
	public Account createAccount(Account account);

	public Account searchAccount(String id);

	public Account addBalance(Account acconut, double balance);

	public Account witdrawFromBalance(Account account, double balance);

	public void transferFund(Account account, Account newAccount, double balance, String description);

	public List<Account> getAllAccount(int userid); // Find User's Account

	public List<Account> getAllAccounts(int userid); // FInd All Account of All user except current user
}
