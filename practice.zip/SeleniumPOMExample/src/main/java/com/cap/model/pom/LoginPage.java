package com.cap.model.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	WebDriver driver = null;

	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public LoginPage() {
		// TODO Auto-generated constructor stub
	}

	@FindBy(id = "username")
	WebElement user;

	@FindBy(id = "password")
	WebElement password;

	@FindBy(id = "signin")
	WebElement submitbutton;

	public void typeUsername(String username) {
		user.sendKeys(username);
	}

	public void typePassword(String pass) {
		password.sendKeys(pass);
	}

	public void clickSignIn() {
		submitbutton.click();
	}

	public void loginWithCredentials(String username, String password) throws InterruptedException {
		Thread.sleep(2000);
		typeUsername(username);
		Thread.sleep(2000);
		typePassword(password);
		Thread.sleep(2000);
		clickSignIn();
		Thread.sleep(2000);
	}
}
