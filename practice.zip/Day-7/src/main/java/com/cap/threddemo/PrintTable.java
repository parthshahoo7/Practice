package com.cap.threddemo;

public class PrintTable implements Runnable {

	int num;

	public PrintTable(int num) {
		super();
		this.num = num;
	}

	public void printMultiplicationTable() {
		for (int i = 1; i < 10; i++) {
			System.out.println("Id:" + Thread.currentThread().getId());
			System.out.println(1 + "*" + num + "=" + i * num + Thread.currentThread().getName());
		}
	}

	@Override
	synchronized public void run() {
		// TODO Auto-generated method stub
		printMultiplicationTable();
	}
}
