package org.cap.demo.hasa;

import java.time.LocalDateTime;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.jpa.model.Customer;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub

		// Obtain EMF object from persistanceContext
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("capg");

		// emf Populates entity manager
		EntityManager entityManager = emf.createEntityManager();

		// get Transaction object to perform transactions
		EntityTransaction entityTransaction = entityManager.getTransaction();
		Employee employee = new Employee(1001, "tim");
		Employee employee2 = new Employee(1002, "da");

		entityTransaction.begin();
		entityManager.persist(employee);
		entityManager.persist(employee2);
		entityTransaction.commit();
		entityManager.close();
	}

}
