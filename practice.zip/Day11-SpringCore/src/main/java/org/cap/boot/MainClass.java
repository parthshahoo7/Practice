package org.cap.boot;

import org.cap.model.Employee;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("myBeans.xml");
		Employee employee = (Employee) context.getBean("emp");

		System.out.println(employee);
		context.close();
	}

}
