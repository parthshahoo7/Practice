package org.cap.wallet.view;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.wallet.model.Account;
import org.cap.wallet.model.Address;
import org.cap.wallet.model.Transactions;
import org.cap.wallet.model.User;
import org.cap.wallet.util.UserUtility;
import org.cap.wallet.model.Account.AccountType;
import org.cap.wallet.service.AccountServiceImpl;
import org.cap.wallet.service.IAccountService;
import org.cap.wallet.service.ITransactionService;
import org.cap.wallet.service.IUserService;
import org.cap.wallet.service.TransactionServiceImpl;
import org.cap.wallet.service.UserServiceImpl;

public class UserInteraction {
	private Scanner sc = new Scanner(System.in);
	private static final AtomicInteger count = new AtomicInteger(1000);
	private String detail;
	private String confirmPassword;
	IUserService iUserService = new UserServiceImpl();
	IAccountService iAccountService = new AccountServiceImpl();

	private User getUserDetails() {
		User user = new User();
		try {
			detail = getUserFirstName();
			while (!UserUtility.isValidUserFirstName(detail)) {
				System.out.println("Enter Valid FirstName");
				detail = getUserFirstName();
			}
			user.setFirstName(detail);
			detail = getUserLastName();
			while (!UserUtility.isValidUserFirstName(detail)) {
				System.out.println("Enter Valid LastName!!");
				detail = getUserLastName();
			}
			user.setLastName(detail);
			user.setAddress(getUserAddress());
			detail = getUserPassword();
			while (!UserUtility.isValidUserPassword(detail)) {
				System.out.println("Paasword Does not meet Criteria!"); // (?=.*[0-9]) a digit must occur at least
				detail = getUserPassword(); // once�(?=.*[a-z]) a lower case letter must occur
				// at least once�(?=.*[A-Z]) an upper case letter
				// must occur at least once �(?=.*[@#$%^&+=]) a
				// special character must occur at least
				// once�(?=\\S+$) no whitespace allowed in the
				// entire string�.{8,} at least 8 characters

			}
			confirmPassword = getUserPassword();
			while (!detail.equals(confirmPassword)) {
				System.out.println("Paasword Does not matched!"); // (?=.*[0-9]) a digit must occur at least
				confirmPassword = getUserPassword();
			}
			user.setPassword(detail);
			detail = getUserEmail();
			while (!UserUtility.isValidUserEmailID(detail)) {
				System.out.println("Enter Valid EmailID!!");
				detail = getUserEmail();
			}
			user.setEmailId(detail);
			detail = getUserDateofBirth();
			LocalDate date = null;
			// DateTimeFormatter simpleDateFormat =
			// DateTimeFormatter.ofPattern("yyyy-mm-dd");
			while (!UserUtility.isValidUserDateofBirth(detail)) {
				System.out.println("Please Enter date in Valid format! (yyyy-mm-dd)");
				detail = getUserPassword();
			}
			date = LocalDate.parse(detail);
			user.setDateOfBirth(date);
			detail = getUserSsn();
			while (!UserUtility.isValidSsn(detail)) {
				System.out.println("Enter SSN in Valid Format!(xxx-xx-xxxx)");
				detail = getUserSsn();
			}
		} catch (Exception e) {
			System.out.println("Sorry!Try Again!");
		}
		return iUserService.addUser(user);
	}

	private String getUserSsn() {
		// TODO Auto-generated method stub
		String ssn;
		System.out.println("Enter SSN (xxx-xx-xxxx):");
		ssn = sc.next();
		return ssn;
	}

	private String getUserDateofBirth() {
		// TODO Auto-generated method stub
		String dobString;
		System.out.println("Enter Date of Birth in yyyy-mm-dd format:");
		dobString = sc.next();
		return dobString;
	}

	private Account getAccount(User user) {
		// TODO Auto-generated method stub
		Account account = new Account();
		double balance;
		int selection;
		System.out.println("Select the Account you want to Open:");
		System.out.println("1. Savings");
		System.out.println("2. Checking");
		selection = sc.nextInt();
		if (selection == 1) {
			account.setAccountType(AccountType.Savings);
		} else if (selection == 2) {
			account.setAccountType(AccountType.Checking);
		}
		System.out.println("Enter Amount:");
		balance = sc.nextDouble();
		while (!UserUtility.isValidBalance(balance)) {
			System.out.println("Minimum Balance Must be 1000$");
			balance = sc.nextDouble();
		}
		account.setBalance(balance);
		System.out.println("Enter Description:");
		account.setDiscription(sc.next());
		account.setUser(user);

//		account.setAccountId(getAccountId());
		// account.setTransactions(null);

		return iAccountService.createAccount(account);
	}

	/*
	 * private String getAccountId() { String name = "Cap"; String id = name +
	 * count.incrementAndGet(); // TODO Auto-generated method stub return id; }
	 */

	private String getUserEmail() {
		// TODO Auto-generated method stub
		String email;
		System.out.println("Eneter Eamil:");
		email = sc.next();
		return email;
	}

	private String getUserPassword() {
		// TODO Auto-generated method stub
		String password;
		System.out.println("Enter Password:");
		password = sc.next();
		return password;
	}

	private Address getUserAddress() throws InputMismatchException {
		Address address = new Address();
		String record;
		int rec;
		System.out.println("Enter House Number:");
		rec = sc.nextInt();
		while (!UserUtility.isValidNumber(rec)) {
			System.out.println("Enter Valid House Number!");
			rec = sc.nextInt();
		}
		address.setHouseNumber(rec);
		System.out.println("Enter Street Address:");
		record = sc.next();
		while (!UserUtility.isValidString(record)) {
			System.out.println("Entry must be in Character!");
			record = sc.next();
		}
		address.setStreetName(record);
		System.out.println("Enter City:");
		record = sc.next();
		while (!UserUtility.isValidString(record)) {
			System.out.println("Entry must be in Character!");
			record = sc.next();
		}
		address.setCity(record);
		System.out.println("Enter State:");
		record = sc.next();
		while (!UserUtility.isValidString(record)) {
			System.out.println("Entry must be in Character!");
			record = sc.next();
		}
		address.setState(record);
		System.out.println("Enter Pincode:");
		rec = sc.nextInt();
		while (!UserUtility.isValidPincode(rec)) {
			System.out.println("Enter Valid Pincode!");
			rec = sc.nextInt();
		}
		address.setZipcode(rec);
		return address;
	}

	private String getUserFirstName() {
		String firstName;
		System.out.println("Eneter FirstName:");
		firstName = sc.next();
		return firstName;
	}

	private String getUserLastName() {
		// TODO Auto-generated method stub
		String lastName;
		System.out.println("Eneter LastName:");
		lastName = sc.next();
		return lastName;
	}

	public void Menu() {
		try {
			int choice = 0;
			while (choice != 3) {
				User user = null;
				System.out.println("Welcome to the Wallet Application!");
				System.out.println("Please Select the Option that you want to perform!");
				System.out.println("1. SignUp");
				System.out.println("2. Signin");
				System.out.println("3. Exit");
				choice = sc.nextInt();
				switch (choice) {
				case 1:
					user = getUserDetails();
					if (user != null) {
						System.out.println("Welcome Your User Id is:" + user.getUserId());
					} else {
						System.out.println("Sorry There is an issue with the application please try again letter!");
					}
					break;
				case 2:
					String password;
					String email;
					System.out.println("Enter Email:");
					email = sc.next();
					System.out.println("Enter Password:");
					password = sc.next();
					user = iUserService.loginUser(email, password);
					if (user != null) {
						System.out.println("Welocome! You can access now follwing features:");
						displayAccountMenu(user);
					} else {
						System.out.println("Sorry! User Not Found Please try Again! Or Signup With System.");
					}
					break;
				default:
					break;
				}
			}
		} catch (Exception e) {
			System.out.println("Sorry! There is problem in your Entry Please Try Again!");
		}
	}

	private void displayAccountMenu(User user) {
		int choice = 0;
		String id;
		double balance = 0;
		Account account = null;
		while (choice != 7) {
			System.out.println("1. Create Account");
			System.out.println("2. Deposit");
			System.out.println("3. WithDraw");
			System.out.println("4. CheckBalance");
			System.out.println("5. Transaction Summary");
			System.out.println("6. Fund Transfer");
			System.out.println("7. Exit");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				account = getAccount(user);
				System.out.println("Your Account Id:" + account.getAccountId());
				account = null;
				break;
			case 2:
				System.out.println("Enter Account Id:");
				id = sc.next();
				account = iAccountService.searchAccount(id);
				if (account != null) {
					System.out.println("Enter Amount to be deposited:");
					balance = sc.nextDouble();
					account = iAccountService.addBalance(account, balance);
					System.out.println("Updated Account Balance is:" + account.getBalance());
				} else {
					System.out.println("Sorry Enter Wrong Account ID! Please Try Again!");
				}
				break;
			case 3:
				System.out.println("Enter Account Id:");
				id = sc.next();
				account = iAccountService.searchAccount(id);
				if (account != null) {
					System.out.println("Enter Amount to be Withdraw:");
					balance = sc.nextDouble();
					double reqBalance = account.getBalance() - 1000;
					if (balance < reqBalance) {
						account = iAccountService.witdrawFromBalance(account, balance);
						System.out.println("Updated Account Balance is:" + account.getBalance());
					} else {
						System.out.println("Sorry Entered Ammount is not valid!");
					}
				} else {
					System.out.println("Sorry Enter Wrong Account ID! Please Try Again!");
				}
				break;
			case 4:
				System.out.println("Enter Account Id:");
				id = sc.next();
				account = iAccountService.searchAccount(id);
				if (account != null) {
					System.out.println("Your Balance is:" + account.getBalance());
				} else {
					System.out.println("Sorry Enter Wrong Account ID! Please Try Again!");
				}
				break;
			case 5:
				System.out.println("Enter Account Id:");
				id = sc.next();
				account = iAccountService.searchAccount(id);
				if (account != null) {
					List<Transactions> transactions = new TransactionServiceImpl()
							.viewAllTransactions(account.getAccountId());
					System.out.print("Transaction Type" + "\t");
					System.out.print("Transaction Date" + "\t");
					System.out.print("Transaction Amount" + "\t");
					System.out.print("From" + "\t\t\t");
					System.out.print("To" + "\t");
					System.out.println();
					System.out.println(
							"-------------------------------------------------------------------------------------------------------------------");

					for (Transactions transactions2 : transactions) {
						System.out.print(transactions2.getTransactionType() + "\t\t\t");
						System.out.print(transactions2.getTransactionDate() + "\t\t");
						System.out.print(transactions2.getAmount() + "\t\t\t");
						System.out.print(transactions2.getFromAccountId() + "\t\t");
						System.out.print(transactions2.getToAccountId() + "\t");
						System.out.println();
					}
				} else {
					System.out.println("Sorry Enter Wrong Account ID! Please Try Again!");
				}
				break;
			case 6:
				System.out.println("Enter Your Account Id:");
				id = sc.next();
				Account newAccount = null;
				account = iAccountService.searchAccount(id);
				if (account != null) {
					String receiverAccount;
					System.out.println("Enter Receiver Account Id");
					receiverAccount = sc.next();
					newAccount = iAccountService.searchAccount(receiverAccount);
					if (newAccount != null) {
						System.out.println("Enter Amount to be Transfered:");
						balance = sc.nextDouble();
						double reqBalance = account.getBalance() - 1000;
						if (balance > reqBalance) {
							System.out.println("sorry! You can not Transfer Fund!");
						} else {
							iAccountService.transferFund(account, newAccount, balance);
						}
					} else {
						System.out.println("Entered Receiver Account is not Found! Please Try Again!");
					}
					System.out.println("Your Balance is:" + account.getBalance());
				} else {
					System.out.println("Sorry Enter Wrong Account ID! Please Try Again!");
				}

				break;
			case 7:
				break;
			default:
				break;
			}
		}
	}

}