package org.cap.filedemo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileDemo {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String source, destination;
		System.out.println("Enter Source File:");
		source = sc.next();
		System.out.println("Enter Destination File:");
		destination = sc.next();
		int c;
		String path = "C:\\Users\\partshah\\OneDrive - Capgemini\\Desktop\\demo\\";
		File file = new File(path + source);
		File newFile = new File(path + destination);
		if (file.exists()) {
			try {
				FileReader fr = new FileReader(file);
				FileWriter fw = new FileWriter(newFile);
				while ((c = fr.read()) != -1) {
					fw.write(c);
				}
				fw.close();
				fr.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}
}
