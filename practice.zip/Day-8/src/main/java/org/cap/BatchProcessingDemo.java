package org.cap;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class BatchProcessingDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		String s1 = "insert into employee values(320,'kamal','cdscsd',21312,false,'2019-09-09')";
		String s3 = "update employee set isPermenant=true";

//		String s2 = "insert into employee values(310,'lvksf','sdvv',89244,false,'2019-10-12')";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/capgedbs";
			Connection connection = DriverManager.getConnection(url, "root", "1234");
			if (connection != null) {
				Statement statement = connection.createStatement();
				// statement.addBatch(s1);
				// statement.addBatch(s2);
				statement.addBatch(s3);
				int[] output = statement.executeBatch();
				for (int i : output)
					System.out.println(i);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
