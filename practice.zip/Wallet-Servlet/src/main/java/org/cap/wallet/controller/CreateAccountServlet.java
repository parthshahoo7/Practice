package org.cap.wallet.controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.wallet.model.Account;
import org.cap.wallet.model.Account.AccountType;
import org.cap.wallet.model.Transactions.TransactionType;
import org.cap.wallet.model.Transactions;
import org.cap.wallet.model.User;
import org.cap.wallet.service.AccountServiceImpl;
import org.cap.wallet.service.IAccountService;
import org.cap.wallet.service.ITransactionService;
import org.cap.wallet.service.TransactionServiceImpl;

/**
 * Servlet implementation class CreateAccountServlet
 */
@WebServlet("/CreateAccountServlet")
public class CreateAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		IAccountService accountService = new AccountServiceImpl();
		Account account = new Account();
		ITransactionService transactionService = new TransactionServiceImpl();
		Transactions transaction = new Transactions();
		String accountType = request.getParameter("accountType");
		Double balance = Double.parseDouble(request.getParameter("balance"));
		String description = request.getParameter("description");
		HttpSession session = request.getSession();
		int userid = (int) session.getAttribute("userid");
		User user = new User();
		user.setUserId(userid);
		if (accountType.equalsIgnoreCase(AccountType.Checking.toString())) {
			account.setAccountType(AccountType.Checking);
		} else if (accountType.equalsIgnoreCase(AccountType.Savings.toString())) {
			account.setAccountType(AccountType.Savings);
		}
		account.setBalance(balance);
		account.setOpeningDate(LocalDate.now());
		account.setUser(user);
		account.setDiscription(description);
		Account account2 = accountService.createAccount(account);
		if (account2 != null) {
			transaction.setAccount(account);
			transaction.setAmount(account.getBalance());
			transaction.setTransactionType(TransactionType.credit);
			transaction.setDescription(account.getDiscription());
			transaction.setTransactionDate(account2.getOpeningDate());
			transactionService.addTransaction(transaction);
			response.setContentType("text/html");
			response.getWriter().println("<h1>Registration Completed!</h1>");
			response.getWriter().println("<a href=\"pages/home.html\">Want to go back? </a>");
		}

	}

}
