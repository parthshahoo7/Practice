package com.capgemini.wagescalc;

import java.util.Scanner;

public class Employee {

	private int id;
	private String firstName, lastName, address;
	private int noOfDaysWorked;
	private double amtPerDay;
	private double salary;

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(int id, String firstName, String lastName, String address) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
	}

	public void display() {
		System.out.println("EmployeeId: " + id);
		System.out.println("FirstName: " + firstName);
		System.out.println("LastName: " + lastName);
		System.out.println("Address: :" + address);
	}

	public void amountPayable() {
		// noOfDaysWorked and amtPerDay using scanner class
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Howmany Days worked:");
		this.noOfDaysWorked = sc.nextInt();
		System.out.println("Enter Amount Per Day:");
		this.amtPerDay = sc.nextDouble();
		salary = this.noOfDaysWorked * this.amtPerDay;
		System.out.println(salary);
	}

	public double showSalary() {
		salary = this.noOfDaysWorked * this.amtPerDay;
		return salary;
	}

}
