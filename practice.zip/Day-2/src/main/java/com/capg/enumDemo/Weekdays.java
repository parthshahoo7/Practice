package com.capg.enumDemo;

public enum Weekdays {
	MON, TUE, WED, THUR, FIR, SUN(1), SAT(7);
	private int value;

	private Weekdays(int value) {
		this.value = value;
	}

	private Weekdays() {

	}

	public int getValue() {
		return this.value;
	}
}
