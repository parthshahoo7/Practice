package com.cap.exercise;

public class ShutDownDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Runtime obj = Runtime.getRuntime();
		obj.addShutdownHook(new CleanUp());
	}

}
