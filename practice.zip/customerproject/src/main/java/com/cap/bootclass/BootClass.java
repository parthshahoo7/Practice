package com.cap.bootclass;

import java.util.Scanner;

import com.cap.service.CustomerServiceImpl;
import com.cap.service.IcustomerService;
import com.cap.userinteraction.UserInteractions;

public class BootClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserInteractions ui = new UserInteractions();
		ui.ui();
	}

}
