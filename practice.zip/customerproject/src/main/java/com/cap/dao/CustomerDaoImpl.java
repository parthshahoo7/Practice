package com.cap.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import com.cap.model.Customer;

public class CustomerDaoImpl implements IcustomerDao {

	private static List<Customer> customers = new ArrayList<Customer>();

	@Override
	public List<Customer> addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		customers.add(customer);
		return customers;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		// TODO Auto-generated method stub
		boolean flag = false;
		Iterator<Customer> iterator = customers.iterator();
		while (iterator.hasNext()) {
			if (iterator.next().getCustomerId() == customerId) {
				iterator.remove();
				flag = true;
			}
		}
		return flag;
	}

	@Override
	public Customer getCustomer(int customerId) {
		// TODO Auto-generated method stub
		Customer customer1 = new Customer();
		for (Customer customer : customers) {
			if (customer.getCustomerId() == customerId) {
				customer1 = customer;
			}
		}
		return customer1;
	}

	@Override
	public List<Customer> viewAllCustomer() {
		// TODO Auto-generated method stub
		return customers;
	}

	@Override
	public List<Customer> updateCustomer(Customer customer) {
		int index = customers.indexOf(customer);
		customers.set(index, customer);
		return customers;
		// TODO Auto-generated method stub

	}

}
