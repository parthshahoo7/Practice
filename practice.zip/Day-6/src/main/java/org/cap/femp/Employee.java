package org.cap.femp;

import java.io.Serializable;
import java.time.LocalDate;

public class Employee implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int employeeId;
	private String firstName;
	private String lastName;
	private double salary;
	private boolean isPermenant;
	private LocalDate dateOfjoining;

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public boolean isPermenant() {
		return isPermenant;
	}

	public void setPermenant(boolean isPermenant) {
		this.isPermenant = isPermenant;
	}

	public LocalDate getDateOfjoining() {
		return dateOfjoining;
	}

	public void setDateOfjoining(LocalDate dateOfjoining) {
		this.dateOfjoining = dateOfjoining;
	}

	public Employee() {

	}

	public Employee(int employeeId, String firstName, String lastName, double salary, boolean isPermenant,
			LocalDate dateOfjoining) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.isPermenant = isPermenant;
		this.dateOfjoining = dateOfjoining;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", salary=" + salary + ", isPermenant=" + isPermenant + ", dateOfjoining=" + dateOfjoining + "]";
	}

}