package org.cap.wallet.model;

import java.time.LocalDate;
import java.util.Date;

public class Transactions {
	public enum TransactionType {
		credit, debit;
	}

	private TransactionType transactionType;
	private LocalDate transactionDate;
	private double amount;
	private String description;
	private String fromAccountId;
	private String toAccountId;
	private Account account;

	public Transactions(TransactionType transactionType, LocalDate transactionDate, double amount, String description,
			String fromAccountId, String toAccountId, Account account) {
		super();
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.amount = amount;
		this.description = description;
		this.fromAccountId = fromAccountId;
		this.toAccountId = toAccountId;
		this.account = account;
	}

	public Transactions() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Transactions(TransactionType transactionType, LocalDate transactionDate, double amount, String description,
			String fromAccountId, String toAccountId) {
		super();
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.amount = amount;
		this.description = description;
		this.fromAccountId = fromAccountId;
		this.toAccountId = toAccountId;
	}

	public TransactionType getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(TransactionType transactionType) {
		this.transactionType = transactionType;
	}

	public LocalDate getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFromAccountId() {
		return fromAccountId;
	}

	public void setFromAccountId(String fromAccountId) {
		this.fromAccountId = fromAccountId;
	}

	public String getToAccountId() {
		return toAccountId;
	}

	public void setToAccountId(String toAccountId) {
		this.toAccountId = toAccountId;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	@Override
	public String toString() {
		return "Transactions [transactionType=" + transactionType + ", transactionDate=" + transactionDate + ", amount="
				+ amount + ", description=" + description + ", fromAccountId=" + fromAccountId + ", toAccountId="
				+ toAccountId + ", account=" + account + "]";
	}

}
