package org.cap.jpa.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "customerDetails")
public class Customer {
	@Id
	@GeneratedValue
	private int customerId;
	@Column(nullable = false, length = 50)
	private String fName;

	@Basic // it's by default notation you don't need to define.
	private String lName;
	@Column(name = "regFees")
	private double registrationFees;

	private boolean isValidCustomer;

	@Column(unique = true)
	private String emailId;
	private LocalDateTime regDate;

	@Enumerated(EnumType.STRING)
	private Location location;

	@ElementCollection
	@OrderBy("fname")
	private List<Customer> customers = new ArrayList<Customer>();

	public Customer(int customerId, String fName, String lName, double registrationFees, boolean isValidCustomer,
			String emailId, LocalDateTime regDate, Location location, List<Customer> customers) {
		super();
		this.customerId = customerId;
		this.fName = fName;
		this.lName = lName;
		this.registrationFees = registrationFees;
		this.isValidCustomer = isValidCustomer;
		this.emailId = emailId;
		this.regDate = regDate;
		this.location = location;
		this.customers = customers;
	}

	public Customer(int customerId, String fName, String lName, double registrationFees, boolean isValidCustomer,
			String emailId, LocalDateTime regDate, Location location) {
		super();
		this.customerId = customerId;
		this.fName = fName;
		this.lName = lName;
		this.registrationFees = registrationFees;
		this.isValidCustomer = isValidCustomer;
		this.emailId = emailId;
		this.regDate = regDate;
		this.location = location;
	}

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(int customerId, String fName, String lName, double registrationFees, boolean isValidCustomer,
			String emailId, LocalDateTime regDate) {
		super();
		this.customerId = customerId;
		this.fName = fName;
		this.lName = lName;
		this.registrationFees = registrationFees;
		this.isValidCustomer = isValidCustomer;
		this.emailId = emailId;
		this.regDate = regDate;
	}

	public Customer(String fName, String lName, double registrationFees, boolean isValidCustomer, String emailId,
			LocalDateTime regDate) {
		super();
		this.customerId = customerId;
		this.fName = fName;
		this.lName = lName;
		this.registrationFees = registrationFees;
		this.isValidCustomer = isValidCustomer;
		this.emailId = emailId;
		this.regDate = regDate;
	}

	public Customer(int customerId, String fName, String lName, double registrationFees) {
		super();
		this.customerId = customerId;
		this.fName = fName;
		this.lName = lName;
		this.registrationFees = registrationFees;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public double getRegistrationFees() {
		return registrationFees;
	}

	public void setRegistrationFees(double registrationFees) {
		this.registrationFees = registrationFees;
	}

	public boolean isValidCustomer() {
		return isValidCustomer;
	}

	public void setValidCustomer(boolean isValidCustomer) {
		this.isValidCustomer = isValidCustomer;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public LocalDateTime getRegDate() {
		return regDate;
	}

	public void setRegDate(LocalDateTime regDate) {
		this.regDate = regDate;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public List<Customer> getCustomers() {
		return customers;
	}

	public void setCustomers(List<Customer> customers) {
		this.customers = customers;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", fName=" + fName + ", lName=" + lName + ", registrationFees="
				+ registrationFees + ", isValidCustomer=" + isValidCustomer + ", emailId=" + emailId + ", regDate="
				+ regDate + ", location=" + location + ", customers=" + customers + "]";
	}

}
