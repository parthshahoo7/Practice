package org.cap.wallet.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.wallet.model.Account;
import org.cap.wallet.model.User;
import org.cap.wallet.service.AccountServiceImpl;
import org.cap.wallet.service.IAccountService;

/**
 * Servlet implementation class CheckBalanceServlet
 */
@WebServlet({ "/CheckBalanceServlet", "/checkbalance" })
public class CheckBalanceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.setContentType("text/html");
		String accountid = request.getParameter("accountID");
		IAccountService accountService = new AccountServiceImpl();
		Account account = accountService.searchAccount(accountid);
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		List<Account> accounts = accountService.getAllAccount(user.getUserId());
		double amount = 0;
		if (account != null) {
			PrintWriter out = response.getWriter();
			amount = account.getBalance();
			out.println("<!DOCTYPE html>\r\n" + "<html>\r\n" + "<head>\r\n" + "<meta charset=\"ISO-8859-1\">\r\n"
					+ "<title>Insert title here</title>\r\n"
					+ "<link href=\"css/bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\">\r\n" + "\r\n"
					+ "<!-- Custom styles for this template -->\r\n"
					+ "<link href=\"css/full-width-pics.css\" rel=\"stylesheet\">\r\n" + "\r\n"
					+ "<!-- Css For Login  -->\r\n" + "\r\n" + "\r\n" + "\r\n" + "\r\n" + "\r\n"
					+ "<link rel=\"stylesheet\"\r\n"
					+ "	href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\">\r\n"
					+ "<script\r\n"
					+ "	src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js\"></script>\r\n"
					+ "<script\r\n"
					+ "	src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>\r\n"
					+ "<link href=\"css/mycss.css\" rel=\"stylesheet\">" + "</head>\r\n" + "<!-- Navigation -->\r\n"
					+ "	<nav class=\"navbar navbar-expand-lg navbar-dark bg-dark fixed-top\">\r\n"
					+ "		<div class=\"container\">\r\n"
					+ "			<a class=\"navbar-brand\" href=\"pages/home.html\">Capg-Wallet</a>\r\n"
					+ "			<button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\"\r\n"
					+ "				data-target=\"#navbarResponsive\" aria-controls=\"navbarResponsive\"\r\n"
					+ "				aria-expanded=\"false\" aria-label=\"Toggle navigation\">\r\n"
					+ "				<span class=\"navbar-toggler-icon\"></span>\r\n" + "			</button>\r\n"
					+ "			<div class=\"collapse navbar-collapse\" id=\"navbarResponsive\">\r\n"
					+ "				<ul class=\"navbar-nav ml-auto\">\r\n"
					+ "					<li class=\"nav-item active\"><a class=\"nav-link\"\r\n"
					+ "						href=\"pages/home.html\">Home <span class=\"sr-only\">(current)</span>\r\n"
					+ "					</a></li>\r\n"
					+ "					<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
					+ "						href=\"pages/registeraccount.html\">Create Account</a></li>\r\n"
					+ "					<li class=\"nav-item\"><a class=\"nav-link\" href=\"transaction\">Transaction</a></li>\r\n"
					+ "					<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
					+ "						href=\"checkbalance\">Check Balance</a></li>\r\n"
					+ "					<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
					+ "						href=\"fundtransfer\">FundTransfer</a></li>\r\n"
					+ "					<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
					+ "						href=\"transactionsummary\">Transaction Summary</a></li>\r\n"
					+ "					<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
					+ "						href=\"LogoutServlet\">Logout</a></li>\r\n" + "				</ul>\r\n"
					+ "			</div>\r\n" + "		</div>\r\n" + "	</nav>\r\n"
					+ "	<!-- Header - set the background image for the header in the line below -->" + "<body>\r\n"
					+ "	<div class=\"login-form\"><form method=\"post\" action=\"checkbalance\">\r\n"
					+ "		<h1 align=\"center\">Check Balance</h1>\r\n" + "		<hr>\r\n" + "		<table>\r\n"
					+ "			<tr>\r\n");
			out.println("				<td>Choose Account:</td>\r\n"
					+ "				<td><div class=\\\"form-group\\\">	<select name=\"accountID\" >\r\n");
			for (Account acc : accounts) {
				out.println("<option value=" + acc.getAccountId() + ">" + acc.getAccountId() + "</option>\r\n");
			}

			out.println("</select></div></td>" + "			</tr>\r\n" + "			<tr>\r\n"
					+ "				<td>	<div class=\"form-group\"><button type=\"submit\" class=\"btn btn-primary \">Perform Transaction</button></div></td>\r\n"
					+ "				<td>	<div class=\"form-group\"><button type=\"reset\" class=\"btn btn-primary \">Clear</button></div></td>\r\n"
					+ "			</tr>\r\n" + "		</table>\r\n");
			out.println("<h1>Amount:" + amount + "</h1>\r\n");
			out.println("	</form>\r\n</div>");

			out.println("</body>\r\n" + "</html>");
		}
		// response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { // TODO
		HttpSession session = req.getSession();
		User user = (User) session.getAttribute("user");
		IAccountService accountService = new AccountServiceImpl();
		List<Account> accounts = accountService.getAllAccount(user.getUserId());
		PrintWriter out = resp.getWriter();
		out.println("<!DOCTYPE html>\r\n" + "<html>\r\n" + "<head>\r\n" + "<meta charset=\"ISO-8859-1\">\r\n"
				+ "<title>Insert title here</title>\r\n"
				+ "<link href=\"css/bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\">\r\n" + "\r\n"
				+ "<!-- Custom styles for this template -->\r\n"
				+ "<link href=\"css/full-width-pics.css\" rel=\"stylesheet\">\r\n" + "\r\n"
				+ "<!-- Css For Login  -->\r\n" + "\r\n" + "\r\n" + "\r\n" + "\r\n" + "\r\n"
				+ "<link rel=\"stylesheet\"\r\n"
				+ "	href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\">\r\n"
				+ "<script\r\n"
				+ "	src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js\"></script>\r\n"
				+ "<script\r\n"
				+ "	src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>\r\n"
				+ "<link href=\"css/mycss.css\" rel=\"stylesheet\">" + "</head>\r\n" + "<!-- Navigation -->\r\n"
				+ "	<nav class=\"navbar navbar-expand-lg navbar-dark bg-dark fixed-top\">\r\n"
				+ "		<div class=\"container\">\r\n"
				+ "			<a class=\"navbar-brand\" href=\"pages/home.html\">Capg-Wallet</a>\r\n"
				+ "			<button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\"\r\n"
				+ "				data-target=\"#navbarResponsive\" aria-controls=\"navbarResponsive\"\r\n"
				+ "				aria-expanded=\"false\" aria-label=\"Toggle navigation\">\r\n"
				+ "				<span class=\"navbar-toggler-icon\"></span>\r\n" + "			</button>\r\n"
				+ "			<div class=\"collapse navbar-collapse\" id=\"navbarResponsive\">\r\n"
				+ "				<ul class=\"navbar-nav ml-auto\">\r\n"
				+ "					<li class=\"nav-item active\"><a class=\"nav-link\"\r\n"
				+ "						href=\"pages/home.html\">Home <span class=\"sr-only\">(current)</span>\r\n"
				+ "					</a></li>\r\n"
				+ "					<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
				+ "						href=\"pages/registeraccount.html\">Create Account</a></li>\r\n"
				+ "					<li class=\"nav-item\"><a class=\"nav-link\" href=\"transaction\">Transaction</a></li>\r\n"
				+ "					<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
				+ "						href=\"checkbalance\">Check Balance</a></li>\r\n"
				+ "					<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
				+ "						href=\"fundtransfer\">FundTransfer</a></li>\r\n"
				+ "					<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
				+ "						href=\"transactionsummary\">Transaction Summary</a></li>\r\n"
				+ "					<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
				+ "						href=\"LogoutServlet\">Logout</a></li>\r\n" + "				</ul>\r\n"
				+ "			</div>\r\n" + "		</div>\r\n" + "	</nav>\r\n"
				+ "	<!-- Header - set the background image for the header in the line below -->" + "<body>\r\n"
				+ "	<div class=\"login-form\"><form method=\"post\" action=\"checkbalance\">\r\n"
				+ "		<h1 align=\"center\">Check Balance</h1>\r\n" + "		<hr>\r\n" + "		<table>\r\n"
				+ "			<tr>\r\n");
		out.println("				<td>Choose Account:</td>\r\n"
				+ "				<td><div class=\"form-group\">	<select name=\"accountID\" >\r\n");
		for (Account acc : accounts) {
			out.println("<option value=" + acc.getAccountId() + ">" + acc.getAccountId() + "</option>\r\n");
		}

		out.println("</select></div></td>" + "			</tr>\r\n" + "			<tr>\r\n"
				+ "				<td>	<div class=\"form-group\"><button type=\"submit\" class=\"btn btn-primary \">Perform Transaction</button></div></td>\r\n"
				+ "				<td>	<div class=\"form-group\"><button type=\"reset\" class=\"btn btn-primary \">Clear</button></div></td>\r\n"
				+ "			</tr>\r\n" + "		</table>\r\n" + "	</form>\r\n</div>" + "</body>\r\n" + "</html>");

	}

}
