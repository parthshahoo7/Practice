package org.cap.demo.practice;

public class Module extends Prroject {

	private String moduleName;

	public Module() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Module(String moduleName) {
		super();
		this.moduleName = moduleName;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

}
