package org.cap.demo.service;

import java.util.List;

import org.cap.demo.model.Employee;

public interface IDbEmployeeService {
	public List<Employee> getAllEmployee();

	public Employee findEmployee(Integer empID);

	public List<Employee> deleteEmployee(Integer empId);

	public List<Employee> createEmployee(Employee employee);

	public List<Employee> updateEmployee(Employee employee);

	public List<Employee> updateEmployeeFirstName(Integer empId, String firstName);
}
