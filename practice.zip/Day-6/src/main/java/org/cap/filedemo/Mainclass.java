package org.cap.filedemo;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Mainclass {

	public static void main(String[] args) {
		// ArrayList<filedatainputstreademo> data = new
		// ArrayList<filedatainputstreademo>();
		Scanner sc = new Scanner(System.in);
		filedatainputstreademo fdemo = new filedatainputstreademo();
		try (FileOutputStream fout = new FileOutputStream(
				"C:\\Users\\partshah\\OneDrive - Capgemini\\Desktop\\demo\\des.txt");
				DataOutputStream dout = new DataOutputStream(fout);) {
			for (int i = 0; i <= 2; i++) {

				System.out.println("Enter Emp ID:");
				fdemo.setEmployeeid(sc.nextInt());
				System.out.println("Enter Gender:");
				fdemo.setGender(sc.next().charAt(0));
				System.out.println("Enter Salary:");
				fdemo.setSalary(sc.nextDouble());
				System.out.println("Enter Emp name:");
				fdemo.setName(sc.next());
				fdemo.setLengthofname(fdemo.getName().length());

				dout.writeInt(fdemo.getEmployeeid());
				dout.writeChar(fdemo.getGender());
				dout.writeDouble(fdemo.getSalary());
				dout.writeInt(fdemo.getLengthofname());
				dout.writeBytes(fdemo.getName());
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try (FileInputStream fin = new FileInputStream(
				"C:\\\\Users\\\\partshah\\\\OneDrive - Capgemini\\\\Desktop\\\\demo\\\\des.txt");
				DataInputStream di = new DataInputStream(fin);) {
			for (int i = 0; i < 3; i++) {
				int empid = di.readInt();
				char gender = di.readChar();
				double sal = di.readDouble();
				int len = di.readInt();
				byte[] b = new byte[len];
				di.read(b);
				String name = new String(b);
				System.out.println(empid + "\t" + gender + "\t" + sal + "\t" + name);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
