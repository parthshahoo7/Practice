package org.cap.wallet.model;

public class Address {
	private int houseNumber;
	private String streetName;
	private String Country;
	private String City;
	private String State;
	private int zipcode;

	public Address(int houseNumber, String streetName, String country, String city, String state, int zipcode) {
		super();
		this.houseNumber = houseNumber;
		this.streetName = streetName;
		Country = country;
		City = city;
		State = state;
		this.zipcode = zipcode;
	}

	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getHouseNumber() {
		return houseNumber;
	}

	public void setHouseNumber(int houseNumber) {
		this.houseNumber = houseNumber;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getCountry() {
		return Country;
	}

	public void setCountry(String country) {
		Country = country;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}

	public int getZipcode() {
		return zipcode;
	}

	public void setZipcode(int zipcode) {
		this.zipcode = zipcode;
	}

}
