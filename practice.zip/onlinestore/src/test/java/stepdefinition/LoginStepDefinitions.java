package stepdefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinitions {
	@Given("^User is on Login Page$")
	public void user_is_on_Login_Page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		System.out.println("Login Page");
	}

	@When("^User enters valid username and password$")
	public void user_enters_valid_username_and_password() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		System.out.println("Login Page Form");
	}

	@Then("^User successfully login and can see welcome page$")
	public void user_successfully_login_and_can_see_welcome_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		System.out.println("Welcome Page");
	}
}
