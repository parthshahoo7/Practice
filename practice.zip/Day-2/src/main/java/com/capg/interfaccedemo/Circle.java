package com.capg.interfaccedemo;

public class Circle implements Ishape, IGraphic {

	@Override
	public void move() {
		// TODO Auto-generated method stub
		System.out.println("Move Method!");

	}

	@Override
	public void scroll() {
		// TODO Auto-generated method stub
		System.out.println("Scroll Method!");

	}

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("Draw Method!");

	}

	@Override
	public void fillshape() {
		// TODO Auto-generated method stub
		System.out.println("FillShape Method!");

	}

	@Override
	public void newShowInfo() {
		System.out.println("Default method of Interface can overidden but not the static Methods!");
	}

}
