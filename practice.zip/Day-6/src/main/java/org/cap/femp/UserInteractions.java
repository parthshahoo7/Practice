package org.cap.femp;

import java.time.LocalDate;
import java.util.Scanner;

public class UserInteractions {
	Scanner sc = new Scanner(System.in);

	public int displayMenu() {
		System.out.println("1.Create Employee");
		System.out.println("2.View All Employee");
		System.out.println("3.Find Employee");
		System.out.println("4.Exit");
		System.out.println("Enter your choice:");
		int choice = sc.nextInt();
		return choice;
	}

	public Employee getEmployeeDetails() {
		Employee employee = new Employee();
		System.out.println("Enter Employee ID:");
		employee.setEmployeeId(sc.nextInt());

		System.out.println("Enter Employee FirstName:");
		employee.setFirstName(sc.next());

		System.out.println("Enter Employee LAstName:");
		employee.setLastName(sc.next());

		System.out.println("Enter Employee Salary:");
		employee.setSalary(sc.nextDouble());

		System.out.println("Is Permanaent? [true|false]");
		employee.setPermenant(sc.nextBoolean());

		employee.setDateOfjoining(LocalDate.now());

		return employee;
	}

}
