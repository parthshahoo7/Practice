package com.cap.stepdefinitions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SignInStepDefinitions {
	WebDriver driver = new ChromeDriver();

	@Given("^user is on login page$")
	public void user_is_on_login_page() throws Throwable {
		driver.manage().window().maximize();
		driver.get("http://localhost:8080/SeleniumDynamicProjectDemo/sign_in.html");
	}

	@When("^user enters valid username and password$")
	public void user_enters_valid_username_and_password(DataTable arg1) throws Throwable {
		List<List<String>> list = arg1.raw();
		for (int i = 0; i < list.size(); i++) {
			Thread.sleep(2000);
			driver.findElement(By.id("username")).sendKeys(list.get(i).get(0));
			Thread.sleep(2000);
			driver.findElement(By.id("password")).sendKeys(list.get(i).get(1));
			Thread.sleep(2000);
			driver.findElement(By.id("signin")).click();
			Thread.sleep(2000);
			driver.navigate().back();
			Thread.sleep(2000);
			driver.navigate().refresh();

		}

		/*
		 * List<String> list = arg1.asList(String.class);
		 * driver.findElement(By.id("username")).sendKeys(list.get(0));
		 * driver.findElement(By.id("password")).sendKeys(list.get(1));
		 */
	}

	@Then("^user is navigated to home page$")
	public void user_is_navigated_to_home_page() throws Throwable {
		driver.quit();
		/*
		 * driver.findElement(By.id("signin")).click(); Thread.sleep(2000);
		 * driver.quit();
		 */
	}

}
