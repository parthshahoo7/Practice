package org.cap.demo;

import org.cap.demo.example.GreetingWebClient;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day14SpringBoot1Application {

	public static void main(String[] args) {
		SpringApplication.run(Day14SpringBoot1Application.class, args);
		GreetingWebClient client=new GreetingWebClient();
		System.out.println(client.getResult());
	}

}
