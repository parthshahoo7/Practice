package org.cap.niodemo;

import java.nio.file.Path;
import java.nio.file.Paths;

public class NioDemoClass {

	public static void main(String[] args) {
	//	Path path=Paths.get(first, more)
		// create a 3 diffrent files and merge them into one file using nio file channel.
	}

}
