package com.cap.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import com.cap.dao.CustomerDaoImpl;
import com.cap.dao.IcustomerDao;
import com.cap.model.Customer;

public class CustomerServiceImpl implements IcustomerService {
	private static final AtomicInteger count = new AtomicInteger(1000);
	private IcustomerDao customerDao = new CustomerDaoImpl();

	@Override
	public List<Customer> addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		customer.setCustomerId(getCustomerId());
		return customerDao.addCustomer(customer);
	}

	private int getCustomerId() {
		int id = 0;
		id = count.incrementAndGet();
		// TODO Auto-generated method stub
		return id;
	}

	@Override
	public List<Customer> deleteCustomer(int customerId) {
		// TODO Auto-generated method stub
		if (customerDao.deleteCustomer(customerId)) {
			return customerDao.viewAllCustomer();
		}
		return null;
	}

	@Override
	public List<Customer> viewAllCustomer() {
		// TODO Auto-generated method stub
		return customerDao.viewAllCustomer();
	}

	@Override
	public List<Customer> updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
//		customerDao.updateCustomer(int customerId);
		return customerDao.updateCustomer(customer);
	}

	@Override
	public Customer searchCustomer(int customerId) {
		// TODO Auto-generated method stub
		return customerDao.getCustomer(customerId);
	}

	@Override
	public List<Customer> sortCustomer(int choice) {
		// TODO Auto-generated method stub
		return null;
	}

}
