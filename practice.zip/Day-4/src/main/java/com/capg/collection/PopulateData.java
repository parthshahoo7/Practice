package com.capg.collection;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.TreeSet;

public class PopulateData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		ArrayList<Customer> customers = new ArrayList<Customer>();
		Customer customer1 = new Customer(12, "TOM", "Jerry565", 234.45, LocalDate.now());
		Customer customer8 = new Customer(18, "TOM5", "Jerry5k", 23434.45, LocalDate.now());
		Customer customer2 = new Customer(13, "TOM1", "Jerry1", 2234.45, LocalDate.now());
		Customer customer3 = new Customer(14, "TOM2", "Jerry2", 2314.45, LocalDate.now());
		Customer customer4 = new Customer(15, "TOM3", "Jerry3", 2314.45, LocalDate.now());
		Customer customer5 = new Customer(16, "TOM4", "Jerry4", 2324.45, LocalDate.now());
		Customer customer6 = new Customer(17, "TOM5", "Jerry5", 23434.45, LocalDate.now());
		Customer customer7 = new Customer(17, "TOM5", "Jerry5", 23434.45, LocalDate.now());

//		HashSet<Customer> hashSet = new HashSet<Customer>();
		LinkedHashSet<Customer> hashSet = new LinkedHashSet<Customer>();

		// TreeSet<Customer> hashSet = new TreeSet<Customer>();
		// List<Customer> hashSet = new ArrayList<Customer>();
		Comparator<Customer> comparator = new Comparator<Customer>() {

			@Override
			public int compare(Customer o1, Customer o2) {
				// TODO Auto-generated method stub
				return o1.getLastName().compareTo(o2.getLastName());
			}
		};
		hashSet.add(customer1);
		hashSet.add(customer8);
		hashSet.add(customer2);
		hashSet.add(customer3);
		hashSet.add(customer4);
		hashSet.add(customer5);
		hashSet.add(customer6);
		hashSet.add(customer7);

//		Collections.sort(hashSet, comparator);
//		Collections.sort(hashSet, new SortByFirstName());
		System.out.println(customer6.hashCode());
		System.out.println(customer7.hashCode());

		Iterator<Customer> iterator = hashSet.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}

	}

}
