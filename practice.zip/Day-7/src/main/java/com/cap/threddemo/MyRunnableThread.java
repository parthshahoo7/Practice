package com.cap.threddemo;

public class MyRunnableThread implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for (int i = 1; i <= 10; i++) {
			System.out.println(i + "*5=" + (i * 5) + Thread.currentThread().getName());
		}
	}

}
