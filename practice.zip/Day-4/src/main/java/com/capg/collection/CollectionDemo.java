package com.capg.collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.function.UnaryOperator;

public class CollectionDemo {
	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList();
		/*
		 * List list1 = new ArrayList(); Collection list2 = new ArrayList();
		 */
		list.add(23);
		list.add(2);
		list.add(10);
		list.add(99);
		list.add(87);
		list.add(0);
//		list.add(null);
//		list.add(null);
//		list.add(2.5f);
//		list.add(12.34);
//		list.add("tom");
//		list.add(true);
//		list.add('S');
		System.out.println("List:");
		System.out.println(list);
		System.out.println();
		// Traverse
		// Using for Loop
		System.out.println("------------------------------");
		System.out.println("Using For Loop:");
		for (Integer li : list) {
			System.out.print(li + ",");
		}
		System.out.println();
		/*
		 * for (int li : list) { System.out.print(li + ","); } System.out.println();
		 * This function generate error due to null. It can not parse the null value so
		 * it generate NULLPINTEREXCEPTION.
		 */
		// using Iterator
		System.out.println("------------------------------");

		System.out.println("Using Iterator:");
		Iterator<Integer> iterator = list.iterator();

		while (iterator.hasNext()) {
			System.out.print(iterator.next() + ",");
		}
		System.out.println();
		// Using ListIterator
		System.out.println("------------------------------");
		System.out.println("Using ListIterator:");
		ListIterator<Integer> listIterator = list.listIterator();
		while (listIterator.hasNext()) {
			System.out.print(listIterator.next() + ",");
		}
		System.out.println();
		// --In reverse
		while (listIterator.hasPrevious()) {
			System.out.print(listIterator.previous() + ",");
		}

		// work---> all methods of list aa,
		// addALl,clear,contains,containsAll,ensurecapcity,equals,get,indexof,isempty,lastindexof,listiteractor(index),remove,
		// removeall,replaceall,retainall,size,sublist,toarray
		list.add(10);
		ArrayList<Integer> list1 = new ArrayList<Integer>();
		list1.add(10);
		list.add(20);
		list1.add(30);
		list1.add(40);
		list1.add(50);
		list.addAll(list);

		System.out.println("Contains 0?:" + list.contains(0));
		System.out.println("Does List contains all emlements of List1?:" + list.containsAll(list1));
		list.ensureCapacity(1000);
		System.out.println("Does list 1 and list equal?:" + list.equals(list1));

		ArrayList<Integer> list3 = new ArrayList<Integer>();
		list3 = list;
		list3.add(999);
		System.out.println(list3.toString());
		System.out.println(list.get(0));
		System.out.println(list.indexOf(10));
		ListIterator<Integer> iiterator2 = list.listIterator(5);
		System.out.println("iterator2:" + iiterator2.toString());
		System.out.println(list3.indexOf(0));
		list3.remove(0);
		System.out.println(list.toString());
		System.out.println(list.subList(5, 10));
		System.out.println("cadcd" + list3.retainAll(list1));
		System.out.println(list3.toString());
		Object[] a = list.toArray();
		System.out.println(a.length);
		list1.clear();
	}
}
