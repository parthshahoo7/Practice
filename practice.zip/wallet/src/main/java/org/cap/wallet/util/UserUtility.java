package org.cap.wallet.util;

public class UserUtility {

	public static boolean isValidUserFirstName(String firstName) {
		return firstName.matches("[A-Z][a-zA-Z]+");
	}

	public static boolean isValidNumber(int rec) {
		// TODO Auto-generated method stub
		String s = Integer.toString(rec);
		return s.matches("\\d{1,6}");
	}

	public static boolean isValidString(String record) {
		// TODO Auto-generated method stub
		return record.matches("[a-zA-Z]+");
	}

	public static boolean isValidPincode(int rec) {
		// TODO Auto-generated method stub
		String s = Integer.toString(rec);
		return s.matches("\\d{5}");
	}

	public static boolean isValidUserPassword(String password) {
		// TODO Auto-generated method stub
		return password.matches("(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}");
	}

	public static boolean isValidUserEmailID(String emailId) {
		// TODO Auto-generated method stub
		return emailId.matches("^(.+)@(.+)$");
	}

	public static boolean isValidUserDateofBirth(String date) {
		// TODO Auto-generated method stub
		return date.matches("^((19|2[0-9])[0-9]{2})-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])$");
	}

	public static boolean isValidSsn(String ssn) {
		// TODO Auto-generated method stub
		return ssn.matches("^(?!000|666)[0-8][0-9]{2}-(?!00)[0-9]{2}-(?!0000)[0-9]{4}$");
	}

	public static boolean isValidBalance(double balance) {
		// TODO Auto-generated method stub
		double minbal = 1000;
		boolean flag = true;
		if (balance < minbal)
			flag = false;
		return flag;
	}

}
