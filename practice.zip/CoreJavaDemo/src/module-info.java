module CoreJavaDemo {
}