package innnerouterdemo;

public class MainClass {
	public static void main(String[] args) {
		InnerOuterDemo out = new InnerOuterDemo();
		out.display();

		new InnerOuterDemo() {
			public void fill() {
				System.out.println("Fill!!!");
			}
		}.fill();

		Shape shape = new Shape() {

			@Override
			public void draw() {
				// TODO Auto-generated method stub
				System.out.println("Annonymus Inner Interface");

			}
		};
		shape.draw();

//		Shape shape = new Shape() {
//
//			@Override
//			public void draw() {
//				// TODO Auto-generated method stub
//				System.out.println("From Main Class!");
//
//			}
//		};
//		shape.draw();

	}

}
