package com.capg.interfaccedemo;

public interface IGraphic {

	public void move();

	public void scroll();

}
