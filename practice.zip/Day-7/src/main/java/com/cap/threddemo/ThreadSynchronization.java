package com.cap.threddemo;

public class ThreadSynchronization {
	public static int i = 0;

	synchronized public static void display(String name) {
		++i;
		for (int i = 1; i <= name.length(); i++) {
			System.out.println(name.substring(0, i) + "----" + Thread.currentThread().getName());
		}
		System.out.println("count:" + i);
	}

	public void printMultiplicationTable() {
		synchronized (this) {
			System.out.println("Thread Name:" + Thread.currentThread().getName());

		}

	}
}