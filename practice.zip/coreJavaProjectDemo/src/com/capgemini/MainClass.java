package com.capgemini;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee employee = new Employee();
		employee.setEmployeeId(1000);
		System.out.println("Employee Id:" + employee.getEmployeeId());

	}

}
