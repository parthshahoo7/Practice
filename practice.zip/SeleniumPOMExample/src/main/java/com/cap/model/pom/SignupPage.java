package com.cap.model.pom;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class SignupPage {
	WebDriver driver = null;

	public SignupPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "username")
	WebElement username;

	@FindBy(id = "password")
	WebElement pass;

	@FindBy(id = "confirmpassword")
	WebElement cpass;

	@FindBy(id = "country")
	WebElement cou;

	@FindBy(name = "gender")
	WebElement gender;

	@FindBy(id = "tc")
	WebElement tc;

	@FindBy(id = "signup")
	WebElement signup;

	public void typeUsername(String username) {
		this.username.sendKeys(username);
	}

	public void typePassword(String password) {
		pass.sendKeys(password);
	}

	public void typeConfirmPassword(String confirmPassword) {
		cpass.sendKeys(confirmPassword);
	}

	public void selectOption() {
		Select s = new Select(cou);
		s.selectByValue("usa");
	}

	public void selectGender() {
		if (!gender.isSelected()) {
			gender.click();
		}
	}

	public void selectTC() {
		if (!tc.isSelected())
			tc.click();
	}

	public void submit() {
		signup.click();
	}

	public void handlePopUp() {
		Alert popup = driver.switchTo().alert();
		popup.accept();
	}

	public void handleAlert() {
		Alert popup = driver.switchTo().alert();
		popup.accept();
	}

	public void signUpWithData(String username, String password, String confirmPassword) throws InterruptedException {
		Thread.sleep(2000);
		typeUsername(username);
		Thread.sleep(2000);
		typePassword(password);
		Thread.sleep(2000);
		typeConfirmPassword(confirmPassword);
		Thread.sleep(2000);
		selectOption();
		Thread.sleep(2000);
		selectGender();
		Thread.sleep(2000);
		selectTC();
		Thread.sleep(2000);
		submit();
		Thread.sleep(2000);
		handlePopUp();
		Thread.sleep(2000);
		handleAlert();
		Thread.sleep(3000);
	}
}
