package org.cap.wallet.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Account {
	public enum AccountType {
		Savings, Checking;
	}

	private AccountType accountType;
	private double balance;
	private String accountId;
	private List<Transactions> transaction;
	private LocalDate openingDate;
	private String discription;
	private User user;

	public Account(AccountType accountType, double balance, String accountId, List<Transactions> transaction,
			LocalDate openingDate, String discription, User user) {
		super();
		this.accountType = accountType;
		this.balance = balance;
		this.accountId = accountId;
		this.transaction = transaction;
		this.openingDate = openingDate;
		this.discription = discription;
		this.user = user;
	}

	public Account(AccountType accountType, double balance, String accountId, List<Transactions> transaction,
			LocalDate openingDate, String discription) {
		super();
		this.accountType = accountType;
		this.balance = balance;
		this.accountId = accountId;
		this.transaction = transaction;
		this.openingDate = openingDate;
		this.discription = discription;
	}

	public Account() {
		super();
		transaction = new ArrayList<Transactions>();
		setTransaction(transaction);
		// TODO Auto-generated constructor stub
	}

	public AccountType getAccountType() {
		return accountType;
	}

	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public List<Transactions> getTransaction() {
		return transaction;
	}

	public void setTransaction(List<Transactions> transaction) {
		this.transaction = transaction;
	}

	public LocalDate getOpeningDate() {
		return openingDate;
	}

	public void setOpeningDate(LocalDate openingDate) {
		this.openingDate = openingDate;
	}

	public String getDiscription() {
		return discription;
	}

	public void setDiscription(String discription) {
		this.discription = discription;
	}

	public void addTransaction(Transactions transaction) {
		this.transaction.add(transaction);
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Account [accountType=" + accountType + ", balance=" + balance + ", accountId=" + accountId
				+ ", transaction=" + transaction + ", openingDate=" + openingDate + ", discription=" + discription
				+ ", user=" + user + "]";
	}

}