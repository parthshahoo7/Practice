package org.cap.wallet.controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.wallet.model.Address;
import org.cap.wallet.model.User;
import org.cap.wallet.service.IUserService;
import org.cap.wallet.service.UserServiceImpl;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet({ "/RegistrationServlet", "/registration" })
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		IUserService userService = new UserServiceImpl();
		Address address = new Address();
		User user = new User();

		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String password = request.getParameter("password");
		String emailId = request.getParameter("emailId");
		String dob = request.getParameter("dob");
		String ssn = request.getParameter("ssn");
		String houseNumber = request.getParameter("houseNumber");
		String streetName = request.getParameter("streetName");
		String city = request.getParameter("city");
		String state = request.getParameter("state");
		String zipcode = request.getParameter("zipcode");
		String country = request.getParameter("country");

		address.setHouseNumber(Integer.parseInt(houseNumber));
		address.setStreetName(streetName);
		address.setCity(city);
		address.setState(state);
		address.setZipcode(Integer.parseInt(zipcode));
		address.setCountry(country);

		user.setFirstName(firstName);
		user.setLastName(lastName);
		user.setPassword(password);
		user.setEmailId(emailId);
		user.setDateOfBirth(LocalDate.parse(dob));
		user.setSSN(ssn);
		user.setAddress(address);
		HttpSession session = request.getSession();
		User user2 = userService.addUser(user);
		if (user2 != null) {
			response.setContentType("text/html");
			response.getWriter().println("<h2>Registration Completed!You can Login Now!</h2>");
			request.getRequestDispatcher("index.html").include(request, response);
		}
	}

}
