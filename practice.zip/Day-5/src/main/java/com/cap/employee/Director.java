package com.cap.employee;

public class Director extends Manager {

	private String roles;

	public Director(int employeeId, String firstName, String lastName, double salary, String location) {
		super(employeeId, firstName, lastName, salary, location);
		// TODO Auto-generated constructor stub
	}

	public Director(int employeeId, String firstName, String lastName, double salary) {
		super(employeeId, firstName, lastName, salary);
		// TODO Auto-generated constructor stub
	}

	public Director(int employeeId, String firstName, String lastName, double salary, String location, String roles) {
		super(employeeId, firstName, lastName, salary, location);
		this.roles = roles;
	}

	public String getRoles() {
		return roles;
	}

	public void setRoles(String roles) {
		this.roles = roles;
	}

	

}
