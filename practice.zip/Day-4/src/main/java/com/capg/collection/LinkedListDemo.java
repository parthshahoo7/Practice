package com.capg.collection;

import java.util.LinkedList;

public class LinkedListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<String> list = new LinkedList<String>();
		list.add("Tom");
		list.add("Jerry");
		list.add("Tomas");
		list.add("Tomas");
		list.add("Petterparker");
		list.add("TonnyStark");
		list.addFirst("HarryPotter");
		list.addLast("Dumbldor");
		System.out.println(list);
		System.out.println(list.getFirst());
		list.offerFirst("Captain America");
		System.out.println(list);
		list.push("Captain Marvel");
		System.out.println(list);
		System.out.println(list.peek());
		System.out.println(list);
		list.pop();
		System.out.println(list);
	}

}
