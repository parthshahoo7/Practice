package org.cap.service;

import org.cap.model.userLogin;

public interface ILoginService {
	public boolean Login(userLogin login);
}
