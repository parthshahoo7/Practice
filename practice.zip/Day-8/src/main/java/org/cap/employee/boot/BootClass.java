package org.cap.employee.boot;

import org.cap.employee.Employee;
import org.cap.employee.dao.EmployeeDaoImpl;
import org.cap.employee.dao.IEmplyeeDao;
import org.cap.employee.ui.UserInteractions;

public class BootClass {
	public static void main(String[] args) {
		UserInteractions ui = new UserInteractions();
		IEmplyeeDao emplyeeDao = new EmployeeDaoImpl();
		int id = 0;
		Employee employee = null;
		int choice = 0;
		while (choice != 6) {
			choice = ui.display();
			switch (choice) {
			case 1:
				employee = ui.addEmployee();
				System.out.println(emplyeeDao.addEmployee(employee));
				break;
			case 2:
				id = ui.getEmployeeId();
				System.out.println(emplyeeDao.findEmployee(id));
				break;
			case 3:
				id = ui.getEmployeeId();
				boolean flag = emplyeeDao.deleteEmployee(id);
				if (flag) {
					System.out.println("Employee Data Deleted SuccessFully!");
				} else {
					System.out.println("Sorry Data Not Found!");
				}
				break;
			case 4:
				int selection = ui.updateEmployeeMenu();
				switch (selection) {
				case 1:
					id = ui.getEmployeeId();
					employee = emplyeeDao.findEmployee(id);
					employee = ui.updateEmployeebyFirstName(employee);
					break;

				default:
					break;
				}
				break;

			default:
				break;
			}
		}
	}

}
