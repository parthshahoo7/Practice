package com.capg.abstractDemo;

public abstract class Rectangle extends Shape {

}
