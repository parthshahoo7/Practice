package Assignment;

import java.util.Scanner;

public class DriverClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PlayList playList = new PlayList();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the playlist:");
		int size = sc.nextInt();
		String[] myplaylist = new String[size];
		for (int i = 0; i < myplaylist.length; i++) {
			myplaylist[i] = sc.next();
		}

		System.out.println("Enter the inde of current song:");
		int currentIndex = sc.nextInt();

		System.out.println("Enter the name of the song:");
		String nexSong = sc.next();

		playList.setPlayListSize(size);
		playList.setMyPlayList(myplaylist);

		System.out.println(playList.goToNextSong(currentIndex, nexSong));
	}

}
