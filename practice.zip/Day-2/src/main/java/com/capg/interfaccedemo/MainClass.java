package com.capg.interfaccedemo;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Circle circle = new Circle();
		Ishape.showInfo();
		circle.newShowInfo();

	}

}
