package com.capgemini;

import java.util.Date;

public class Account {
	private int accountNumber;
	private String accountName;
	private String address;
	private String accountType;
	private double openingBalance;
	private Date openingDate;

	public Account(int accountNumber, String accountName, String address, String accountType, double openingBalance,
			Date openingDate) {
		super();
		this.accountNumber = accountNumber;
		this.accountName = accountName;
		this.address = address;
		this.accountType = accountType;
		this.openingBalance = openingBalance;
		this.openingDate = openingDate;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public double getOpeningBalance() {
		return openingBalance;
	}

	public void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}

	public Date getOpeningDate() {
		return openingDate;
	}

	public void setOpeningDate(Date openingDate) {
		this.openingDate = openingDate;
	}

	public void openAccount() {

	}

	public double getBalance() {
		return openingBalance;
	}

	public void deposit() {

	}

	public void withdraw() {

	}
}
