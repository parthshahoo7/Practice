package com.cap.map;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class MapDemo {
	public static void main(String[] args) {
		Map<Integer, String> maps = new HashMap<Integer, String>();
		maps.put(12, "Jack");
		maps.put(13, "dsjn");
		maps.put(14, "Jdjkn");
		maps.put(15, "kkjfcnsd");

		System.out.println(maps);

		Set<Integer> keys = maps.keySet();
		System.out.println(keys);
		System.out.println();
		System.out.println("--------------");
		System.out.println("Printing Key Values:");
		Iterator<Integer> iterator = keys.iterator();
		while (iterator.hasNext()) {
			int key = iterator.next();
			System.out.println(key + "-->" + maps.get(key));
		}
		System.out.println();
		System.out.println("--------------");
		System.out.println("Printing Values:");
		Collection<String> values = maps.values();
		System.out.print(values + ",");
		Set<Entry<Integer, String>> entries = maps.entrySet();
		System.out.println(entries);
	}
}
