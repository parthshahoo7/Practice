package com.cap.threddemo;

public class TestClass {

	public static void main(String[] args) {

		ThreadSynchronization th1 = new ThreadSynchronization();

		Runnable runnable = new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				ThreadSynchronization.display("Capgemini");

			}
		};
		Runnable runnable1 = new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				ThreadSynchronization.display("Capgemini");

			}
		};
		Runnable runnable2 = new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				ThreadSynchronization.display("Capgemini");
				th1.printMultiplicationTable();

			}
		};
		Runnable runnable3 = new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				ThreadSynchronization.display("Capgemini");

			}
		};
		Runnable runnable4 = new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				ThreadSynchronization.display("Capgemini");
				th1.printMultiplicationTable();
			}
		};
		Thread t1 = new Thread(runnable);
		Thread t2 = new Thread(runnable1);
		Thread t3 = new Thread(runnable2);
		Thread t4 = new Thread(runnable3);
		Thread t5 = new Thread(runnable4);
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t5.start();
		// TODO Auto-generated method stub
//		MyThread t1 = new MyThread();
//		t1.setPriority(10);
//		MyThread t2 = new MyThread();
//		t2.setPriority(5);
//		MyThread t3 = new MyThread();
//		t3.setPriority(5);
//		MyThread t4 = new MyThread();
//		t4.setPriority(4);
//
//		t1.start();
//		t2.start();
//		t2.yield();
//		t3.start();
//		t4.start();

		// Daemon thread Example
		/*
		 * SupportThread supportThread = new SupportThread();
		 * supportThread.setDaemon(true); supportThread.start();
		 * System.out.println("Hello This is Thread Demo");
		 */

//		MyThread t1 = new MyThread();
//		t1.setPriority(10);
//		MyThread t2 = new MyThread();
//		t2.setPriority(5);
//		MyThread t3 = new MyThread();
//		t3.setPriority(5);
//		MyThread t4 = new MyThread();
//		t4.setPriority(4);
//
//		t1.start();
//		t2.start();
//		t2.yield();
//		t3.start();
//		t4.start();

//		PrintTable table3 = new PrintTable(15);
//		Thread t3 = new Thread(table3);
//		Thread t2 = new Thread(table3);
//		Thread t1 = new Thread(table3);
//		t1.start();
//		t2.start();
//		t3.start();
	}

}
