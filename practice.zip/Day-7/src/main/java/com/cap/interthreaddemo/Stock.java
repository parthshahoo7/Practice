package com.cap.interthreaddemo;

public class Stock {
	private int quantity;

	public Stock(int quantity) {
		this.quantity = quantity;
	}

	synchronized public void product(int qty) {
		System.out.println("...........I am producer...");
		this.quantity += qty;
		// notify();
		notifyAll();
		System.out.println("Final Quantity:" + this.quantity);
	}

	synchronized public void consume(int qty) {
		System.out.println(".............I am Consumer...");
		while (this.quantity < qty) {
			System.out.println("I am waiting for producer!!!!!!!!!!");
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		this.quantity -= qty;
		System.out.println("Updated Quantity:" + this.quantity);
	}

}
