package org.cap.dao;

import java.util.List;

import org.cap.model.Employee;

public interface IEmployeeDao {
	public void saveEmployee(Employee employee);

	public List<Employee> getEmployees();

	public void deleteEMployee(int employeeId);

	public Employee findEmployee(int employeeId);
}
