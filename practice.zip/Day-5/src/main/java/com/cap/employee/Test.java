package com.cap.employee;

import java.util.List;

public class Test {
	private static double total = 0;

//	public static double sum(List<? extends Number> in) {
//		for (Number i : in) {
//			total += i.doubleValue();
//		}
//		return total;
//	}

	public static void sum(List<?> in) {
		for (Object i : in) {
			System.out.println(i);
		}
		// return total;
	}

	public static void display(List<? super Manager> list) {
		for (Object e : list) {
			System.out.println(e);
		}
	}

}
