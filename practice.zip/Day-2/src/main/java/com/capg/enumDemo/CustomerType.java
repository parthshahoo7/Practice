package com.capg.enumDemo;

public enum CustomerType {
	SILVER(50, 100), GOLD(101, 200);

	private int minValue;
	private int maxValue;

	private CustomerType(int minValue, int maxValue) {
		this.minValue = minValue;
		this.maxValue = maxValue;
	}

	public int getMinValue() {
		return minValue;
	}

	public int getMaxValue() {
		return maxValue;
	}
}
