package org.cap.controller;

import org.cap.model.userLogin;
import org.cap.service.ILoginService;
import org.cap.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {

	@Autowired
	private ILoginService myloginService;
	/*
	 * @RequestMapping("/greet") public ModelAndView greetnewUser() { String msg =
	 * "This is demo! For Spring MVC!"; return new ModelAndView("greetingPage",
	 * "greetmessage", msg); }
	 */
	/*
	 * @RequestMapping(value = "/validateLogin", method = RequestMethod.POST) public
	 * String validateUserLogin(@RequestParam("userName") String userName,
	 * 
	 * @RequestParam("userPassword") String password, ModelMap map) { // boolean
	 * flag = false; if (userName.contentEquals("tom") && password.equals("tom123"))
	 * { map.put("userName", userName); return "mainPage"; } return "redirect:/"; }
	 */

	@RequestMapping(value = "/validateLogin", method = RequestMethod.POST)
	public String validateUserLogin(@RequestParam("userName") String userName,
			@RequestParam("userPassword") String password, ModelMap map) {
		// boolean flag = false;
		userLogin userLogin = new userLogin();
		userLogin.setUserName(userName);
		userLogin.setUserPassword(password);
		if (myloginService.Login(userLogin)) {
			map.put("userName", userName);
			return "mainPage";
		}
		map.put("errmsg", "Sorry!Invalid Login!");
		return "redirect:/";
	}

}
