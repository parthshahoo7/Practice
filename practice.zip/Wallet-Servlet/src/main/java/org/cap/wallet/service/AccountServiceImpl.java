package org.cap.wallet.service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.wallet.dao.AccountDaoImpl;
import org.cap.wallet.dao.IAccountDao;
import org.cap.wallet.model.Account;
import org.cap.wallet.model.Transactions;
import org.cap.wallet.model.Transactions.TransactionType;

public class AccountServiceImpl implements IAccountService {
	private IAccountDao accountDao = new AccountDaoImpl();
	private static final AtomicInteger count = new AtomicInteger(1000);
	private ITransactionService itransactionService = new TransactionServiceImpl();

	private ArrayList<Transactions> transactions = new ArrayList<Transactions>();

	@Override
	public Account createAccount(Account account) {
		Transactions transaction = new Transactions();
		// TODO Auto-generated method stub
		/*
		 * String id; int newid = accountDao.generateAccountId(); id = "cap00000" +
		 * newid; account.setAccountId(id);
		 */LocalDate date = LocalDate.now();
		account.setOpeningDate(date);
		return accountDao.createAccount(account);
	}

	/*
	 * private String getAccountId() { String name = "Cap"; String id = name +
	 * count.incrementAndGet(); // TODO Auto-generated method stub return id; }
	 */
	@Override
	public Account searchAccount(String id) {
		// TODO Auto-generated method stub
		return accountDao.searchAccount(id);
	}

	@Override
	public Account addBalance(Account account, double balance) {
		Transactions transaction = new Transactions();
		// TODO Auto-generated method stub
		double bal = account.getBalance() + balance;
		account.setBalance(bal);
		transaction.setAccount(account);
		transaction.setAmount(balance);
		transaction.setTransactionType(TransactionType.credit);
		transaction.setDescription(account.getDiscription());
		LocalDate date = LocalDate.now();
		transaction.setTransactionDate(date);
		itransactionService.addTransaction(transaction);
		account.addTransaction(transaction);
		return accountDao.updateAccount(account);
	}

	@Override
	public Account witdrawFromBalance(Account account, double balance) {
		Transactions transaction = new Transactions();
		// TODO Auto-generated method stub
		double bal = account.getBalance() - balance;
		account.setBalance(bal);
		transaction.setAccount(account);
		transaction.setAmount(balance);
		transaction.setTransactionType(TransactionType.debit);
		transaction.setDescription(account.getDiscription());
		LocalDate date = LocalDate.now();
		transaction.setTransactionDate(date);
		itransactionService.addTransaction(transaction);
		account.addTransaction(transaction);
		return accountDao.updateAccount(account);
	}

	@Override
	public void transferFund(Account account, Account newAccount, double balance, String description) {
		Transactions transaction = new Transactions();
		Transactions transaction1 = new Transactions();
		// TODO Auto-generated method stub
		double bal = account.getBalance() - balance;
		account.setBalance(bal);
		transaction.setAccount(account);
		transaction.setAmount(balance);
		transaction.setTransactionType(TransactionType.debit);
		transaction.setDescription(description);
		LocalDate date = LocalDate.now();
		transaction.setTransactionDate(date);
		transaction.setFromAccountId(account.getAccountId());
		transaction.setToAccountId(newAccount.getAccountId());
		itransactionService.addTransaction(transaction);
		account.addTransaction(transaction);
		bal = newAccount.getBalance() + balance;
		newAccount.setBalance(bal);
		transaction1.setAccount(newAccount);
		transaction1.setAmount(balance);
		transaction1.setTransactionType(TransactionType.credit);
		transaction1.setDescription(description);
		transaction1.setTransactionDate(date);
		transaction1.setFromAccountId(account.getAccountId());
		transaction1.setToAccountId(newAccount.getAccountId());
		itransactionService.addTransaction(transaction1);
		newAccount.addTransaction(transaction1);
		accountDao.updateAccount(account);
		accountDao.updateAccount(newAccount);
	}

	@Override
	public List<Account> getAllAccount(int userid) {
		// TODO Auto-generated method stub
		return accountDao.getAllAccounts(userid);
	}

	@Override
	public List<Account> getAllAccounts(int userid) {
		// TODO Auto-generated method stub
		return accountDao.getAllusersAccounts(userid);
	}

}
