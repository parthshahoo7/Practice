package com.cap.exercise;

public class DeadLockDemo {

	String s1, s2;

	public void process() {
		System.out.println("Thread Name:" + Thread.currentThread().getName());
		synchronized (s1) {
			System.out.println("Processing String 1....");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		synchronized (s2) {
			System.out.println("Processing String 1....");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {

		String s1 = "Hello";
		String s2 = "Hi";

		// Runna

//		DeadLockDemo d1 = new DeadLockDemo();
//		Runnable r1 = new Runnable() {
//
//			@Override
//			public void run() {
//				// TODO Auto-generated method stub
//				d1.process();
//			}
//		};
//		Runnable r2 = new Runnable() {
//
//			@Override
//			public void run() {
//				// TODO Auto-generated method stub
//				d1.process();
//			}
//		};
//
//		Thread t1 = new Thread(r1);
//		Thread t2 = new Thread(r2);
//		t1.start();
//		t2.start();
	}
}
