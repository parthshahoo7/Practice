package com.cap.dao;

import java.util.List;

import com.cap.model.Customer;

public interface IcustomerDao {

	public List<Customer> addCustomer(Customer customer);

	public boolean deleteCustomer(int customerId);

	public Customer getCustomer(int customerId);

	public List<Customer> viewAllCustomer();

	public List<Customer> updateCustomer(Customer customer);

}
