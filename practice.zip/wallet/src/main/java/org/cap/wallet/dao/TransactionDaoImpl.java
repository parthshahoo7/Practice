package org.cap.wallet.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.cap.wallet.model.Account;
import org.cap.wallet.model.Transactions;
import org.cap.wallet.model.Transactions.TransactionType;

public class TransactionDaoImpl implements ITransactionDao {
	private ArrayList<Transactions> transactions = new ArrayList<Transactions>();

	private Connection getDBConnection() throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.jdbc.Driver");
		String url = "jdbc:mysql://localhost:3306/capg_wallet";

		Connection connection = DriverManager.getConnection(url, "root", "1234");

		return connection;
	}

	@Override
	public Transactions addTransaction(Transactions transaction) {
		try (Connection con = getDBConnection()) {
			String sql = "insert into transaction(transaction_type,amount,description,fromaccountid,toaccountid,accountid,transaction_date) values(?,?,?,?,?,?,?)";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, transaction.getTransactionType().toString());
			pst.setDouble(2, transaction.getAmount());
			pst.setString(3, transaction.getDescription());
			pst.setString(4, transaction.getFromAccountId());
			pst.setString(5, transaction.getToAccountId());
			pst.setString(6, transaction.getAccount().getAccountId());
			pst.setDate(7, Date.valueOf(transaction.getTransactionDate()));

			int count = pst.executeUpdate();
			if (count > 0) {
				return transaction;
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Transactions> viewAllTransactions(String accountid) {
		// TODO Auto-generated method stub
		List<Transactions> transactions = new ArrayList<Transactions>();
		try (Connection conn = getDBConnection()) {
			String sql = "select * from transaction where accountid=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, accountid);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				Transactions transaction = new Transactions();
				Account account = new AccountDaoImpl().searchAccount(rs.getString("accountid"));
				transaction.setAccount(account);
				transaction.setAmount(rs.getDouble("amount"));
				transaction.setDescription(rs.getString("description"));
				transaction.setFromAccountId(rs.getString("fromaccountid"));
				transaction.setToAccountId(rs.getString("toaccountid"));
				if (rs.getString("transaction_type").equals((TransactionType.credit).toString())) {
					transaction.setTransactionType(TransactionType.credit);
				} else if (rs.getString("transaction_type").equals((TransactionType.debit).toString())) {
					transaction.setTransactionType(TransactionType.debit);
				}
				transaction.setTransactionDate(rs.getDate("transaction_date").toLocalDate());
				transactions.add(transaction);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return transactions;
	}

}
