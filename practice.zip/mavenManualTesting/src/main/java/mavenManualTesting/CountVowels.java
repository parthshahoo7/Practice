package mavenManualTesting;

public class CountVowels {

	public static int countNumberofVowels(String string) {
		int count = 0;
		for (int i = 0; i < string.length(); i++) {
			char c = string.charAt(i);
			if (c == 'a' || c == 'A' || c == 'e' || c == 'E' || c == 'i' || c == 'I' || c == 'o' || c == 'O' || c == 'u'
					|| c == 'U') {
				count++;
			}
		}
		return count;
	}

}
