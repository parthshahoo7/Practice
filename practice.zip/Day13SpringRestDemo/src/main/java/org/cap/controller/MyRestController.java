package org.cap.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/greet")
public class MyRestController {

	@RequestMapping("/hello")
	public String sayHello() {
		return "Hello! Greetings from Spring container!";
	}
}
