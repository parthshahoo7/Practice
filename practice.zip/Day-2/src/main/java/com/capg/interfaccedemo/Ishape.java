package com.capg.interfaccedemo;

public interface Ishape {

	public void draw();

	public void fillshape();

	public static void showInfo() {
		System.out.println("Static Method declared in ISHAPE.! New feature of Java-8");
	}

	public default void newShowInfo() {
		System.out.println("Can not access directly!");
	}
}
