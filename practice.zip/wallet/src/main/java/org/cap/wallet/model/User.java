package org.cap.wallet.model;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

public class User {
	private String firstName;
	private String lastName;
	private Address address;
	private String password;
	private List<Account> account;
	private String emailId;
	private int userId;
	private LocalDate dateOfBirth;
	private String SSN;

	public User(String firstName, String lastName, Address address, String password, List<Account> account,
			String emailId, int userId, LocalDate dateOfBirth, String sSN) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.password = password;
		this.account = account;
		this.emailId = emailId;
		this.userId = userId;
		this.dateOfBirth = dateOfBirth;
		SSN = sSN;
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setAccount(List<Account> account) {
		this.account = account;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getSSN() {
		return SSN;
	}

	public void setSSN(String sSN) {
		SSN = sSN;
	}

	@Override
	public String toString() {
		return "User [firstName=" + firstName + ", lastName=" + lastName + ", address=" + address + ", password="
				+ password + ", account=" + account + ", emailId=" + emailId + ", userId=" + userId + ", dateOfBirth="
				+ dateOfBirth + ", SSN=" + SSN + "]";
	}

}
