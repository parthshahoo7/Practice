package innnerouterdemo;

public class InnerOuterDemo {
	int num = 20;

	public void display() {
		class Inner {
			int value = 10;

			public void show() {
				System.out.println("Value:" + value);
				System.out.println("Parent Value:" + num);
			}
		}
		Inner in = new Inner();
		in.show();
	}
}
