package stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CalculatorStepDefinitions {
	@Given("^I have number(\\d+) and number(\\d+)$")
	public void i_have_number_and_number(int arg1, int arg2) throws Throwable {
		System.out.println("I have 2 and 3");
	}

	@When("^I add number(\\d+) and number(\\d+)$")
	public void i_add_number_and_number(int arg1, int arg2) throws Throwable {
		System.out.println("when i add 2 and 3");
	}

	@Then("^result is sum of number(\\d+) and number(\\d+)$")
	public void result_is_sum_of_number_and_number(int arg1, int arg2) throws Throwable {
		System.out.println("Sum is:" + (2 + 3));
	}
	
}
