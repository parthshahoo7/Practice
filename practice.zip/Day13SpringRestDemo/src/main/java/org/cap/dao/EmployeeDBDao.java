package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.cap.model.Employee;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class EmployeeDBDao implements IEmployeeDao {

	private EntityManager entityManager;

	@Override
	public List<Employee> getEmployees() {
		// TODO Auto-generated method stub
		List<Employee> employees = entityManager.createQuery("from Employee").getResultList();
		return employees;
	}

	@Override
	public Employee findEmployee(Integer empID) {
		// TODO Auto-generated method stub
		Employee employee = entityManager.find(Employee.class, empID);
		return employee;
	}

	@Override
	public List<Employee> deleteEmployee(Integer empID) {
		// TODO Auto-generated method stub
		Employee employee = findEmployee(empID);
		entityManager.remove(employee);
		return getEmployees();
	}

	@Override
	public List<Employee> createEmployee(Employee employee) {
		// TODO Auto-generated method stub
		entityManager.persist(employee);
		return getEmployees();
	}

	@Override
	public List<Employee> updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		entityManager.merge(employee);
		return getEmployees();
	}

	@Override
	public List<Employee> partiallyUpdateEmployee(Integer empID, String firstName) {
		// TODO Auto-generated method stub
		Employee employee = findEmployee(empID);
		employee.setFirstName(firstName);
		return getEmployees();
	}

}
