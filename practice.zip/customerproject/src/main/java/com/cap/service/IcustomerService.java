package com.cap.service;

import java.util.List;

import com.cap.model.Customer;

public interface IcustomerService {
	public List<Customer> addCustomer(Customer customer);

	public List<Customer> deleteCustomer(int customerId);

	public List<Customer> viewAllCustomer();

	public List<Customer> updateCustomer(Customer customer);

	public Customer searchCustomer(int customerId);

	public List<Customer> sortCustomer(int choice);

}
