package com.capgemini.wagescalc;

import java.util.Scanner;

public class calculate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Worker worker1 = new Worker();
//		worker1.amountPayable();
//		// System.out.println("Wages" + worker1.showWages());
//
//		Employee emp1 = new Employee();
//		emp1.amountPayable();
		// System.out.println("Salary:" + emp1.showSalary());

		Scanner sc = new Scanner(System.in);
		Employee person = null;
		System.out.println("1.Employee");
		System.out.println("2.Worker");
		System.out.println("Enter Your Option:");
		int option = sc.nextInt();

		if (option == 1) {
			person = new Employee();
		} else if (option == 2) {
			person = new Worker();
		}
		person.amountPayable();
		Employee emp = new Employee(1, "abc", "def", "jkdbc");
		emp.display();
		emp.amountPayable();

		Worker work = (Worker) new Employee();
		work.showSalary();
	}

}
