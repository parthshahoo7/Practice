package com.cap.test.pom;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cap.model.pom.LoginPage;

public class TestLoginPage {
	WebDriver driver = null;

	/*
	 * public static void main(String[] args) throws InterruptedException {
	 * WebDriver driver = null; driver = new ChromeDriver();
	 * driver.manage().window().maximize();
	 * driver.get("http://localhost:8080/SeleniumDynamicProjectDemo/sign_in.html");
	 * LoginPage loginPage = new LoginPage();
	 * loginPage.loginWithCredentials("parth", "parth123"); driver.quit(); }
	 */

	@Before
	public void before() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://localhost:8080/SeleniumDynamicProjectDemo/sign_in.html");
	}

	@Test
	public void testLoginPage() throws InterruptedException {
		LoginPage loginPage = new LoginPage(driver);
		loginPage.loginWithCredentials("parth", "parth123");
	}

	@After
	public void afterTest() {
		driver.quit();
	}

}
