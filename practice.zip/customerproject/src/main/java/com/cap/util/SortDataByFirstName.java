package com.cap.util;

import java.util.Comparator;
import java.util.List;

import com.cap.model.Customer;

public class SortDataByFirstName implements Comparator<Customer> {

	@Override
	public int compare(Customer o1, Customer o2) {
		// TODO Auto-generated method stub
		return o1.getFirstName().compareTo(o2.getFirstName());
	}

}
