package org.cap.dao;

import org.cap.model.UserLogin;

public interface ILoginDao {
	public boolean isValidLogin(UserLogin userLogin);
}
