package com.cap.selenium;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class TestSignupPage {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("http://localhost:8080/SeleniumDynamicProjectDemo/sign_up.html");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		WebElement userName = driver.findElement(By.id("username"));
		userName.sendKeys("parth");
		Thread.sleep(1000);
		WebElement password = driver.findElement(By.id("password"));
		password.sendKeys("password123");
		WebElement confirmPassword = driver.findElement(By.id("confirmpassword"));
		confirmPassword.sendKeys("password123");
		Thread.sleep(1000);
		if (password.getText().equals(confirmPassword.getText())) {
			System.out.println("Password matched!");
		} else {
			System.out.println("Password does not match!");
		}
		WebElement country = driver.findElement(By.id("country"));
		// initialize select
		Select dropdown = new Select(country);
		// select option by index
		// dropdown.selectByIndex(1);
		// select Option by value
		// dropdown.selectByValue("usa");
		// select option by visible text
		dropdown.selectByVisibleText("USA");
		Thread.sleep(1000);
		List<WebElement> list = driver.findElements(By.name("gender"));
		System.out.println("size of radio elements:" + list.size());
		for (int i = 0; i < list.size(); i++) {
			if (!list.get(i).isSelected()) {
				list.get(i).click();
				break;
			}
		}
		Thread.sleep(1000);
		// locate terms and conditions web element and click
		WebElement tandc = driver.findElement(By.id("tc"));
		if (!tandc.isSelected())
			tandc.click();
		Thread.sleep(1000);
		WebElement submit = driver.findElement(By.id("signup"));
		submit.click();
		// Test Pop up
		Alert cbox = driver.switchTo().alert();
		cbox.accept();
		Thread.sleep(2000);
//		Alert alert = driver.switchTo().alert();
//		alert.accept();

//		Thread.sleep(2000);
//		driver.quit();

	}

}
