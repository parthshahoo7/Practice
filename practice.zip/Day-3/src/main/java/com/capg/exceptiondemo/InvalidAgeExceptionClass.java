package com.capg.exceptiondemo;

public class InvalidAgeExceptionClass extends RuntimeException {

	public InvalidAgeExceptionClass() {
//		super("Sorry Invalid Age!");
		// TODO Auto-generated constructor stub
	}

//	public InvalidAgeExceptionClass(String string) {
//		super(string);
//	}

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "Age must be grater then 18!";
	}

}
