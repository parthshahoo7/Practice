package com.capgemini.wagescalc;

import java.util.Scanner;

public class Worker extends Employee {
	private int noOfHours;
	private double amtPerHour;
	private double wages;
	private String companyName;

	public void display() {
		System.out.println("Company Name: " + companyName);

	}

	@Override
	public void amountPayable() {
		// no of days and amtPerDay
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter No of Hours:");
		this.noOfHours = sc.nextInt();
		System.out.println("Enter Amount Per Hour:");
		this.amtPerHour = sc.nextDouble();
		wages = this.noOfHours * this.amtPerHour;
		System.out.println(wages);

	}

	public double showWages() {
		wages = this.noOfHours * this.amtPerHour;
		return wages;
	}

}
