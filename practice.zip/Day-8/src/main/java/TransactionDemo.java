import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Savepoint;

public class TransactionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub//
		// values(310,'lvksf','sdvv',89244,false,'2019-10-12')";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/capgedbs";
			Connection connection = DriverManager.getConnection(url, "root", "1234");
			if (connection != null) {
				String s1 = "insert into employee values(400,'kamal','cdscsd',21312,false,'2019-09-09')";
				String s3 = "update employee set isPermenant=true";
				String s2 = "insert into employee values(410,'lvksf','sdvv',89244,false,'2019-10-12')";
				Savepoint se = null;
				Savepoint se2 = null;
				connection.setAutoCommit(false);
				PreparedStatement prd = connection.prepareStatement(s1);
				PreparedStatement prd1 = connection.prepareStatement(s2);
				PreparedStatement pd2 = connection.prepareStatement(s3);
				prd.executeUpdate();
				se = connection.setSavepoint("Mark1");
				prd1.executeUpdate();
				se2 = connection.setSavepoint("Mark2");
				connection.commit();

				//connection.rollback(se);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block

			e.printStackTrace();
		}

	}

}
