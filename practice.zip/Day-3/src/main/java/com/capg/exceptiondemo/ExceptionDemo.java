package com.capg.exceptiondemo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class ExceptionDemo {
	public static void main(String[] args) {
		int age;

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Age:");
		age = sc.nextInt();
		try {
			if (age > 18)
				throw new InvalidAgeExceptionClass();
		} catch (InvalidAgeExceptionClass e) {
			e.printStackTrace();
		}
//		int[] arr = { 1, 2, 3, 4 };
//		int num1 = 10, num2 = 0;
//
//		File file = new File("C:\\Users\\partshah\\Documents\\sample.txt");
//		FileInputStream fin = null;
//		try {
//			fin = new FileInputStream(file);
//			if (num2 == 0)
//				throw new ArithmeticException("Exception thrown!");
//			int ans = num1 / num2;
//		} catch (FileNotFoundException e) {
//			System.err.println(e);
//		} catch (ArithmeticException e) {
//			System.err.println(e);
//		} finally {
//			try {
//				fin.close();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//		try (FileInputStream fi = new FileInputStream(file);
//				FileOutputStream fo = new FileOutputStream("C:\\Users\\partshah\\Documents\\output.txt")) {
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		} catch (IOException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
	}

	/*
	 * NOTES: User definer exception: must be extend the exception class/ throwable
	 * class /RuntimeException class. --> override - method: -->
	 * getMessage,Super("Custome err msg") --> throw--> exception by using throw
	 * keyword. exception/ throwable are checked exception while runtime exception
	 * class is unchecked exception. checked exception must be handle during compile
	 * time while unchecked exception jandle during run time.
	 */

}
