package com.capg.collection;

import java.time.LocalDate;

public class Customer implements Comparable<Customer> {
	private int customerId;
	private String firstName;
	private String lastName;
	private double registrationFee;
	private LocalDate registrationDate;

	public Customer(int customerId, String firstName, String lastName, double registrationFee,
			LocalDate registrationDate) {
		super();
		this.customerId = customerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.registrationFee = registrationFee;
		this.registrationDate = registrationDate;
	}

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public double getRegistrationFee() {
		return registrationFee;
	}

	public void setRegistrationFee(double registrationFee) {
		this.registrationFee = registrationFee;
	}

	public LocalDate getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(LocalDate registrationDate) {
		this.registrationDate = registrationDate;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", registrationFee=" + registrationFee + ", registrationDate=" + registrationDate + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + customerId;
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((registrationDate == null) ? 0 : registrationDate.hashCode());
		long temp;
		temp = Double.doubleToLongBits(registrationFee);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (customerId != other.customerId)
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (registrationDate == null) {
			if (other.registrationDate != null)
				return false;
		} else if (!registrationDate.equals(other.registrationDate))
			return false;
		if (Double.doubleToLongBits(registrationFee) != Double.doubleToLongBits(other.registrationFee))
			return false;
		return true;
	}

	@Override
	public int compareTo(Customer o) {
		// TODO Auto-generated method stub
//		if (this.customerId > o.customerId) {
//			return 1;
//		} else if (this.customerId < o.customerId) {
//			return -1;
//		}
		if (this.getFirstName().compareTo(o.getFirstName()) < 0) {
			return -1;
		} else if (this.getFirstName().compareTo(o.getFirstName()) > 0) {
			return 1;
		}
		return 0;
	}
}
