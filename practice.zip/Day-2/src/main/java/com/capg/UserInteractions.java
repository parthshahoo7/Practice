package com.capg;

import java.util.Scanner;

import com.capg.Employee.EmployeeType;

public class UserInteractions {

	public Employee getEmployeeDetails() {
		Employee employee = new Employee();

		String id = getEmployeeId();
		while (!Utility.isValidEmployeeID(id)) {
			System.out.println("Enter Valid ID!!");
			id = getEmployeeId();
		}
		employee.setEmployeeId(id);

		String firstName = getEmployeeFirstName();
		while (!Utility.isValidEmployeeFirstName(firstName)) {
			System.out.println("Enter Valid FirstName!!");
			firstName = getEmployeeFirstName();
		}
		employee.setFirstName(firstName);

		String lastName = getEmployeeLastName();
		while (!Utility.isValidEmployeeFirstName(lastName)) {
			System.out.println("Enter Valid LastName!!");
			lastName = getEmployeeLastName();
		}
		employee.setLastName(lastName);

		double salary = getEmployeeSalary();
		while (!Utility.isValidEmployeeSalary(salary)) {
			System.out.println("Enter Valid Salary!!");
			salary = getEmployeeSalary();
		}
		employee.setSalary(salary);

		String emailId = getEmployeeEmailId();
		while (!Utility.isValidEmployeeEmailID(emailId)) {
			System.out.println("Enter Valid EmailID!!");
			emailId = getEmployeeEmailId();
		}
		employee.setEmailId(emailId);

		System.out.println("Types of Employeement:");
		System.out.println("1. Permenent");
		System.out.println("2. Parttime");
		System.out.println("3. Contract");
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		if (choice == 1) {
			employee.setEmployeeType(EmployeeType.Permenent);
		} else if (choice == 2) {
			employee.setEmployeeType(EmployeeType.Parttime);
		} else if (choice == 3) {
			employee.setEmployeeType(EmployeeType.Contract);
		}
		employee.setAddress(getEmployeeAddress());
		return employee;
	}

	private Address getEmployeeAddress() {
		Address address = new Address();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Door No:");
		address.setDoorNo(sc.nextInt());
		System.out.println("Enter Street Address:");
		address.setStreetName(sc.next());
		System.out.println("Enter City:");
		address.setCity(sc.next());
		System.out.println("Enter State:");
		address.setState(sc.next());
		System.out.println("Enter Pincode:");
		address.setPincode(sc.nextInt());
		return address;
	}

	private String getEmployeeEmailId() {
		// TODO Auto-generated method stub
		String emailId;
		Scanner sc = new Scanner(System.in);
		System.out.println("Eneter EmailID:");
		emailId = sc.next();
		return emailId;
	}

	private double getEmployeeSalary() {
		// TODO Auto-generated method stub
		double salary;
		Scanner sc = new Scanner(System.in);
		System.out.println("Eneter Salary:");
		salary = sc.nextDouble();
		return salary;
	}

	private String getEmployeeLastName() {
		// TODO Auto-generated method stub
		String lastName;
		Scanner sc = new Scanner(System.in);
		System.out.println("Eneter LastName:");
		lastName = sc.next();
		return lastName;
	}

	private String getEmployeeFirstName() {
		// TODO Auto-generated method stub
		String firstName;
		Scanner sc = new Scanner(System.in);
		System.out.println("Eneter FirstName:");
		firstName = sc.next();
		return firstName;
	}

	public String getEmployeeId() {
		String id;
		Scanner sc = new Scanner(System.in);
		System.out.println("Eneter EmployeeID:");
		id = sc.next();
		return id;
	}
}
