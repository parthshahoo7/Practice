package org.cap.config;

import java.util.concurrent.TimeUnit;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.CacheControl;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalEntityManagerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@EnableWebMvc
@ComponentScan({"org.cap"})
@EnableTransactionManagement
public class WebMVCConfig implements WebMvcConfigurer{
	
	
	
	
	
	
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/resources/**")
				.addResourceLocations("classpath:/static/")
				.setCacheControl(CacheControl.maxAge(2, TimeUnit.HOURS).cachePublic());
	}


	@Bean
	public LocalEntityManagerFactoryBean getEntityManagerFactoryBean() {
		LocalEntityManagerFactoryBean factoryBean=new LocalEntityManagerFactoryBean();
		factoryBean.setPersistenceUnitName("democapg");
		return factoryBean;
	}
	
	
	@Bean
	public JpaTransactionManager getTransactionBean() {
		JpaTransactionManager transactionManager=
				new JpaTransactionManager(getEntityManagerFactoryBean().getObject());
		return transactionManager;
	}
	
	

	@Override
	public void configureViewResolvers(ViewResolverRegistry registry) {
		InternalResourceViewResolver viewResolver= 
				new InternalResourceViewResolver(); 
		///WEB-INF/jsp/greetPage.jsp
		viewResolver.setPrefix("/WEB-INF/jsp/"); 
		viewResolver.setSuffix(".jsp");
			registry.viewResolver(viewResolver);	
		//registry.jsp("/WEB-INF/jsp/", ".jsp");
	}
	
	
	/*
	 * @Bean public InternalResourceViewResolver getViewResolver() {
	 * InternalResourceViewResolver viewResolver= new
	 * InternalResourceViewResolver(); ///WEB-INF/jsp/greetPage.jsp
	 * viewResolver.setPrefix("/WEB-INF/jsp/"); viewResolver.setSuffix(".jsp");
	 * return viewResolver;
	 * 
	 * }
	 */

	


	
	
	
}
