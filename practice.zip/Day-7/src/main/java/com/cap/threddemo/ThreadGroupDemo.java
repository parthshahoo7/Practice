package com.cap.threddemo;

public class ThreadGroupDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadGroup group = new ThreadGroup("Group1");
		MyThread t1 = new MyThread(group, "Group1");
		MyThread t2 = new MyThread(group, "Group1");
		MyThread t3 = new MyThread(group, "Group1");
		t3.setPriority(7);

		int count = group.activeCount();
		System.out.println("Active COunt:" + count);
		t1.start();
		t2.start();
		t3.start();
		count = group.activeCount();
		System.out.println("Active COunt:" + count);
		System.out.println("Group Name:" + group.getName());
		System.out.println("Max Priority:" + group.getMaxPriority());

	}

}
