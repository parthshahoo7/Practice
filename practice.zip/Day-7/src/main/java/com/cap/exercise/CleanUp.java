package com.cap.exercise;

public class CleanUp extends Thread {

	@Override
	public void run() {
		System.out.println("JVM Terminates............");
		// release connection close file connections
		System.out.println("Doing CLeanUpTask....");
	}
}
