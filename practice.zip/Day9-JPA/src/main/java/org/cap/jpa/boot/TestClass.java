package org.cap.jpa.boot;

import java.time.LocalDateTime;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.cap.jpa.model.Book;
import org.cap.jpa.model.BookId;
import org.cap.jpa.model.Customer;

public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Obtain EMF object from persistanceContext
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("capg");

		// emf Populates entity manager
		EntityManager entityManager = emf.createEntityManager();

		// get Transaction object to perform transactions
		EntityTransaction entityTransaction = entityManager.getTransaction();
		Book book1 = new Book(new BookId(3, 22), "csdsc");
		Book book2 = new Book(new BookId(4, 22), "sfvv");
		entityTransaction.begin();
		entityManager.persist(book1);
		entityManager.persist(book2);
		entityTransaction.commit();
		entityManager.close();
	}

}
