package com.cap.generics;

import com.cap.employee.Employee;
import com.cap.employee.Manager;

public class Sender<T extends Manager, U> {
	private T message;
	private U newmessage;

	public Sender() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Sender(T message) {
		super();
		this.message = message;
	}

	public Sender(T message, U newmessage) {
		super();
		this.message = message;
		this.newmessage = newmessage;
	}

	public U getNewmessage() {
		return newmessage;
	}

	public void setNewmessage(U newmessage) {
		this.newmessage = newmessage;
	}

	public T getMessage() {
		return message;
	}

	public void setMessage(T message) {
		this.message = message;
	}

}
