package com.cap.employee;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee employee = new Employee(1, "dcjksdn", "vkdjsn", 123.23);
		Employee employee1 = new Employee(2, "dcjkfklsvnsdn", "vkdjknjkndjsn", 12123.23);
		Employee employee2 = new Employee(3, "dcjksddksvmvn", "vdsdkdjsn", 12233.23);
		Employee employee3 = new Employee(4, "dcjksddvsvn", "vkdasadcdjsn", 12243.23);
		Employee employee4 = new Employee(5, "advavdcjksdn", "vkqweeqdjsn", 14323.23);
		Employee employee5 = new Employee(5, "advavdcjksdn", "vkqweeqdjsn", 14323.23);

		// Map<Employee, Integer> maps = new HashMap<Employee, Integer>();
		// Map<Employee, Integer> maps = new LinkedHashMap<Employee, Integer>();
		Hashtable<Employee, Integer> maps = new Hashtable<Employee, Integer>();

//		Map<Employee, Integer> maps = new TreeMap<Employee, Integer>();
		maps.put(employee, 0);
		maps.put(employee1, 1);
		maps.put(employee2, 2);
		maps.put(employee3, 3);
		maps.put(employee4, 4);
		maps.put(employee5, 5);

//		maps.put(employee5, null);
//		maps.put(null, 5);

		Enumeration<Employee> enumeration = maps.keys();
		while (enumeration.hasMoreElements()) {
			System.out.println(enumeration.nextElement());
		}
//		Set<Employee> employees = maps.keySet();
//
//		for (Employee emp : employees) {
//			System.out.println(emp + "-->" + maps.get(emp));
//		}

//		TreeMap<Integer, String> treeMap = new TreeMap<Integer, String>();
//		treeMap.put(20, "hfbb");
//		treeMap.put(100, "hfbb");
//		treeMap.put(1, "hfbb");
//		treeMap.put(3, "hfbb");
//		treeMap.put(99, "hfbb");
//		treeMap.put(50, "hfbb");
//
//		System.out.println(treeMap);

//		Set<Integer> set = treeMap.keySet();
//		for (Integer in : set) {
//			System.out.println(in + "" + maps.get(in));
//		}
	}
}
