package org.cap.jpa.model;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class BookId implements Serializable {

	private int bookId;
	private int publishedId;

	public BookId() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BookId(int bookId, int publishedId) {
		super();
		this.bookId = bookId;
		this.publishedId = publishedId;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public int getPublisherId() {
		return publishedId;
	}

	public void setPublisherId(int publisherId) {
		this.publishedId = publisherId;
	}

	@Override
	public String toString() {
		return "BookId [bookId=" + bookId + ", publisherId=" + publishedId + "]";
	}

}
