package org.cap.service;

import org.cap.model.UserLogin;

public interface ILoginService {
	public boolean isValidLogin(UserLogin userLogin);

}
