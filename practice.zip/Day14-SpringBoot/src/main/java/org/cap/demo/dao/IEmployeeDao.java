package org.cap.demo.dao;

import java.util.List;

import org.cap.demo.model.Employee;

public interface IEmployeeDao {
	public List<Employee> getEmployees();

	public Employee findEmployee(Integer empID);

	public List<Employee> deleteEmployee(Integer empID);

	public List<Employee> createEmployee(Employee employee);

	public List<Employee> updateEmployee(Employee employee);

	public List<Employee> partiallyUpdateEmployee(Integer empID, String firstName);
}
