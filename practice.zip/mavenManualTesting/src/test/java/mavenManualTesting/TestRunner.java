package mavenManualTesting;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TestRunner {

	@Test
	public void testFindMax() {
		int nums[] = { -9, -2, -3, -1, -4, -6 };
		int max = FindMax.findMaxArray(nums);
		assertEquals(-1, max);
	}

	@Test
	public void testVowels() {
		String s = "Hello how are you";
		int count = CountVowels.countNumberofVowels(s);
		assertEquals(7, count);
	}

}
