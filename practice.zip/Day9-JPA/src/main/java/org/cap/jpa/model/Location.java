package org.cap.jpa.model;

public enum Location {
	NJ, NY, PA, DC, MD, CT;

}
