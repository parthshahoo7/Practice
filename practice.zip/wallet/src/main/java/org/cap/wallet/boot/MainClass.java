package org.cap.wallet.boot;

import org.cap.wallet.view.UserInteraction;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserInteraction userInteraction = new UserInteraction();
		userInteraction.Menu();
	}

}
