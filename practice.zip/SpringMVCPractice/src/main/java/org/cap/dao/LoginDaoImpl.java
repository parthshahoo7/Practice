package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.cap.model.userLogin;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("loginDao")
@Transactional
public class LoginDaoImpl implements ILoginDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Transactional
	@Override
	public boolean Login(userLogin userLogin) {
		// TODO Auto-generated method stub
		Query query = entityManager
				.createQuery("from userLogin user where user.userName=:userName and user.userPassword=:userPassword");
		query.setParameter("userName", userLogin.getUserName());
		query.setParameter("userPassword", userLogin.getUserPassword());

		List<userLogin> logins = query.getResultList();
		if (logins.size() > 0)
			return true;
		return false;
	}

}
