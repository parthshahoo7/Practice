package org.cap.controller;

import java.util.List;

import org.cap.dao.IEmployeeDao;
import org.cap.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1")
public class EmployeeController {

	@Autowired
	private IEmployeeDao employeeDao;

	@GetMapping("/employees")
	public ResponseEntity<List<Employee>> getAllEmployees() {
		List<Employee> employees = employeeDao.getEmployees();
		if (employees.isEmpty())
			return new ResponseEntity("Sorry! Employees Not Exist!", HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@GetMapping("/employees/{empID}")
	public ResponseEntity<Employee> findEmployee(@PathVariable("empID") Integer empID) {
		Employee employee = employeeDao.findEmployee(empID);
		if (employee == null)
			return new ResponseEntity("Sorry! Employees Not Exist!", HttpStatus.NOT_FOUND);
		return new ResponseEntity<Employee>(employee, HttpStatus.OK);
	}

	@DeleteMapping("/employees/{empID}")
	public ResponseEntity<List<Employee>> deleteEmployee(@PathVariable("empID") Integer empID) {
		List<Employee> employee = employeeDao.deleteEmployee(empID);
		if (employee == null || employee.isEmpty())
			return new ResponseEntity("Sorry! EmployeeID Not Found!", HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Employee>>(employee, HttpStatus.OK);
	}

	@PostMapping("/employees")
	public ResponseEntity<List<Employee>> createEmployee(@RequestBody Employee employee) {
		List<Employee> employees = employeeDao.createEmployee(employee);
		if (employees == null || employees.isEmpty())
			return new ResponseEntity("Sorry! Employee Can Not Created!", HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@PutMapping("/employees")
	public ResponseEntity<List<Employee>> updateEmployee(@RequestBody Employee employee) {
		List<Employee> employees = employeeDao.updateEmployee(employee);
		if (employees == null || employees.isEmpty())
			return new ResponseEntity("Sorry! Employee Can Not Updated!", HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@PatchMapping("/employees/{empID}/{firstName}")
	public ResponseEntity<List<Employee>> partialUpdateEmployee(@PathVariable("empID") Integer empID,
			@PathVariable("firstName") String firstName) {
		List<Employee> employees = employeeDao.partiallyUpdateEmployee(empID, firstName);
		if (employees == null || employees.isEmpty())
			return new ResponseEntity("Sorry! Employee Can Not Updated!", HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}
}
