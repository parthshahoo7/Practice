package org.cap.dao;

import org.cap.model.userLogin;

public interface ILoginDao {
	public boolean Login(userLogin userLogin);
}
