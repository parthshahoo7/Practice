package org.cap.employee.test;

import static org.junit.Assert.*;

import org.cap.employee.dao.EmployeeDaoImpl;
import org.cap.employee.dao.IEmplyeeDao;
import org.junit.Test;

public class TestEmployeeDao {
	private IEmplyeeDao employeeDao = new EmployeeDaoImpl();

	@Test
	public void test() {
		int ans = employeeDao.sumArray(new int[] { 1, 2, 3, 4, 5 });
		assertEquals(15, ans);
//		fail("Not yet implemented");
	}

}
