package com.capg.varargdemo;

public class VarArgeDemo {

	public void getArray(String[] str) {// ,Integer...in) {
		System.out.println("array:");
		for (String s : str)
			System.out.println(s + ",");
		System.out.println();
	}

	public void getName(int num, String... str) { // Vararg comes in java 1.5 can not have multiple varargs
		System.out.println("varargs:");
		for (String s : str)
			System.out.println(s + ",");
		System.out.println();
	}

	public static void main(String[] args) {
		VarArgeDemo var = new VarArgeDemo();
		String[] str = new String[] { "apple", "orange" };
		var.getName(1, "Tom", "jerry", "acbk", "cjasnsk");
		var.getArray(new String[] { "cjasbk", "cjkbaksbc" });
	}
}
