package com.cap.employee;

public class Manager extends Employee {

	private String location;

	public Manager() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Manager(int employeeId, String firstName, String lastName, double salary, String location) {
		super(employeeId, firstName, lastName, salary);
		this.location = location;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Manager(int employeeId, String firstName, String lastName, double salary) {
		super(employeeId, firstName, lastName, salary);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Manager [location=" + location + "]";
	}

}
