package org.cap.service;

import org.cap.dao.ILoginDao;
import org.cap.model.userLogin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("myloginService") // name is optional
public class LoginService implements ILoginService {

	@Autowired
	private ILoginDao loginDao;

	@Override
	public boolean Login(userLogin userLogin) {
		// TODO Auto-generated method stub
		return loginDao.Login(userLogin);
	}

}
