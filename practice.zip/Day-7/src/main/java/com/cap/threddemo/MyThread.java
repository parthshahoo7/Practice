package com.cap.threddemo;

public class MyThread extends Thread {

	public MyThread(String threadName) {
		// TODO Auto-generated constructor stub
		super(threadName);
	}

	public MyThread() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MyThread(ThreadGroup group, String string) {
		// TODO Auto-generated constructor stub
		super(group, string);
	}

	@Override
	synchronized public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.println(this.getName() + " " + "Thread Running....");
		}
	}
}