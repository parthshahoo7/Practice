module coreJavaProjectDemo {
}