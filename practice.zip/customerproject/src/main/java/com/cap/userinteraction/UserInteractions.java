package com.cap.userinteraction;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Scanner;

import com.cap.model.Address;
import com.cap.model.Customer;
import com.cap.service.CustomerServiceImpl;
import com.cap.service.IcustomerService;
import com.cap.util.SortDataByFirstName;
import com.cap.util.SortDataByLastName;

public class UserInteractions {

	Scanner sc = new Scanner(System.in);
	IcustomerService icustomerService = new CustomerServiceImpl();

	public Customer requestCustomerDetails() {
		Customer customer = new Customer();
		System.out.println("Enter FirstName");
		customer.setFirstName(sc.next());
		System.out.println("Enter LastName:");
		customer.setLastName(sc.next());
		System.out.println("Enter Registration Fees:");
		customer.setRegistrationFee(sc.nextDouble());
		System.out.println("Enter Registration Date:");
		customer.setRegistrationDate(LocalDate.parse(sc.next()));
		Address address = new Address();
		System.out.println("Enter Door No:");
		address.setDoorNo(sc.nextInt());
		System.out.println("Enter Street Name:");
		address.setStreetName(sc.next());
		System.out.println("Enter City:");
		address.setCity(sc.next());
		System.out.println("Enter State:");
		address.setState(sc.next());
		System.out.println("Enter Zipcode:");
		address.setPincode(sc.nextInt());
		customer.setAddress(address);
		return customer;
	}

	public int requestCustomerId() {
		int id;
		System.out.println("Enter Customer Id:");
		id = sc.nextInt();
		return id;
	}

	public void ui() {
		int choice = 0, id = 0;
		System.out.println("Welcome to the Customer Data Manipulation System!");
		while (choice != 7) {
			System.out.println("Menu");
			System.out.println("1. Add Customer");
			System.out.println("2. Delete Customer");
			System.out.println("3. View All Customer");
			System.out.println("4. Update Customer");
			System.out.println("5. Sort Customer");
			System.out.println("6. Search Customer");
			System.out.println("7. Exit");
			choice = sc.nextInt();
			switch (choice) {
			case 1:

				System.out.println(icustomerService.addCustomer(requestCustomerDetails()));
				break;
			case 2:
				System.out.println(icustomerService.deleteCustomer(requestCustomerId()));
				break;
			case 3:
				System.out.println(icustomerService.viewAllCustomer());
				break;
			case 4:
				System.out.println("Enter the customer ID:");
				id = sc.nextInt();
				updateCustomerChoice(id);
				break;
			case 5:
				sortCustomerChoice();
				break;
			case 6:
				System.out.println("Enter Customer Id:");
				id = sc.nextInt();
				System.out.println(icustomerService.searchCustomer(id));
				break;
			case 7:
				break;
			default:
				break;
			}
		}

	}

	private void sortCustomerChoice() {
		// TODO Auto-generated method stub
		System.out.println("Please select option from below to sort customer data:");
		int choice = 0;
		System.out.println("1. Sort By CustomerID");
		System.out.println("2. Sort By FirstName");
		System.out.println("3. Sort By LastName");
		choice = sc.nextInt();
		switch (choice) {
		case 1:
			Collections.sort(icustomerService.viewAllCustomer());
			System.out.println(icustomerService.viewAllCustomer());
			break;
		case 2:
			Collections.sort(icustomerService.viewAllCustomer(), new SortDataByFirstName());
			System.out.println(icustomerService.viewAllCustomer());
			break;
		case 3:
			Collections.sort(icustomerService.viewAllCustomer(), new SortDataByLastName());
			System.out.println(icustomerService.viewAllCustomer());
			break;
		default:
			break;
		}
	}

	private void updateCustomerChoice(int customerId) {
		Customer customer = new Customer();
		System.out.println("Please select from the following Menu what you want to Update.");
		int choice = 0;
		String firstName;
		System.out.println("1. FirstName");
		System.out.println("2. LastName");
		choice = sc.nextInt();
		switch (choice) {
		case 1:
			customer = icustomerService.searchCustomer(customerId);
			System.out.println("Enter FirstName:");
			firstName = sc.next();
			customer.setFirstName(firstName);
			System.out.println(icustomerService.updateCustomer(customer));
			break;
		case 2:
			customer = icustomerService.searchCustomer(customerId);
			System.out.println("Enter LastName:");
			firstName = sc.next();
			customer.setLastName(firstName);
			System.out.println(icustomerService.updateCustomer(customer));
			break;
		default:
			break;
		}
		// TODO Auto-generated method stub

	}
}
