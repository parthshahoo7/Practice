package com.capgemini;

import java.util.Scanner;

public class Student {

	// instance variable
	int studentNo;
	String firstName;
	String lastName;
	float registrationFees;

	// instance Method

	public void getStudentDetails() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter First Name:");
		firstName = sc.nextLine();
		System.out.println("Enter Last Name:");
		lastName = sc.nextLine();

		System.out.println("Enter Student No:");
		studentNo = sc.nextInt();
		System.out.println("Enter Registration Fees:");		
		registrationFees = sc.nextFloat();
	}

	public void showStudentDetails() {

		System.out.println("Student No: " + studentNo);
		System.out.println("First Name: " + firstName);
		System.out.println("Last Name: " + lastName);
		System.out.println("Registration Fees: " + registrationFees);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// create object
		// tom -- reference
		// new student() --> object
		
		Student tom = new Student(); // store in heap memory
		
		tom.getStudentDetails();
		tom.showStudentDetails();
	}

}
