package stepdefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SignUpStepDefinitions {
	@Given("^User is on SignUp Page$")
	public void user_is_on_SignUp_Page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		System.out.println("Hello");
	}

	@When("^User enters username,address and password$")
	public void user_enters_username_address_and_password() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		System.out.println("Hello");
	}

	@Then("^User registration successfully and can see login page$")
	public void user_registration_successfully_and_can_see_login_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		System.out.println("Hello");
	}
}
