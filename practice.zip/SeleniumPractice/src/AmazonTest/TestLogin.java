package AmazonTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TestLogin {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.amazon.com/");
		// driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Actions actions = new Actions(driver);
		// WebElement searchsingin=driver.findElement(By.className(className))
		WebElement signin = driver.findElement(By.id("nav-link-accountList"));
		/*
		 * Actions actions = new Actions(driver);
		 * actions.moveToElement(signin).perform(); WebElement btn =
		 * driver.findElement(By.className("nav-action-button")); btn.click();
		 */
		signin.click();
		Thread.sleep(1000);
		WebElement email = driver.findElement(By.id("ap_email"));
		email.sendKeys("parthnileshshah@gmail.com");
		WebElement password = driver.findElement(By.id("ap_password"));
		password.sendKeys("Parth@4559");
		WebElement submit = driver.findElement(By.id("signInSubmit"));
		submit.click();
		Thread.sleep(1000);
		WebElement sbutton = driver.findElement(By.id("nav-link-accountList"));
		actions.moveToElement(sbutton).perform();
		WebElement signout = driver.findElement(By.id("nav-item-signout"));
		signout.click();
		driver.quit();
	}
}
