package org.cap.wallet.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class User {
	@Id
	@GeneratedValue
	private int userId;
	private String firstName;
	private String lastName;

	@OneToOne(mappedBy = "user")
	private Address address;
	private String password;

	@OneToMany(mappedBy = "user")
	private List<Account> account = new ArrayList<Account>();
	private String emailId;
	private LocalDate dateOfBirth;
	private String SSN;

	public User(int userId, String firstName, String lastName, Address address, String password, List<Account> account,
			String emailId, LocalDate dateOfBirth, String sSN) {
		super();
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.password = password;
		this.account = account;
		this.emailId = emailId;
		this.dateOfBirth = dateOfBirth;
		SSN = sSN;
	}

	public User(String firstName, String lastName, Address address, String password, String emailId, int userId,
			LocalDate dateOfBirth, String sSN) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.password = password;
		// this.account = account;
		this.emailId = emailId;
		this.userId = userId;
		this.dateOfBirth = dateOfBirth;
		SSN = sSN;
	}

	public User(String firstName, String lastName, Address address, String password, List<Account> account,
			String emailId, LocalDate dateOfBirth, String sSN) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.password = password;
		this.account = account;
		this.emailId = emailId;
		this.dateOfBirth = dateOfBirth;
		SSN = sSN;
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getSSN() {
		return SSN;
	}

	public void setSSN(String sSN) {
		SSN = sSN;
	}

	public List<Account> getAccount() {
		return account;
	}

	public void setAccount(List<Account> account) {
		this.account = account;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", firstName=" + firstName + ", lastName=" + lastName + ", address=" + address
				+ ", password=" + password + ", account=" + account + ", emailId=" + emailId + ", dateOfBirth="
				+ dateOfBirth + ", SSN=" + SSN + "]";
	}

}
