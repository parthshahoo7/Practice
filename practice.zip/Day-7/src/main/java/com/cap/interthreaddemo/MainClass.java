package com.cap.interthreaddemo;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final Stock stock = new Stock(100);
		Thread consumer1 = new Thread() {
			@Override
			public void run() {
				stock.consume(45);
			}
		};
		consumer1.start();
		Thread consumer2 = new Thread() {
			@Override
			public void run() {
				stock.consume(35);
			}
		};
		consumer2.start();
		Thread consumer3 = new Thread() {
			@Override
			public void run() {
				stock.consume(25);
			}
		};
		consumer3.start();
		Thread producer = new Thread() {
			@Override
			public void run() {
				stock.product(60);
			}
		};
		producer.start();
		Thread consumer4 = new Thread() {
			@Override
			public void run() {
				stock.consume(60);
			}
		};
		consumer4.start();
	}

}
