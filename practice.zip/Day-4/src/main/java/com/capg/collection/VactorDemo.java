package com.capg.collection;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Vector;

public class VactorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector<Integer> vec = new Vector<Integer>();
		vec.add(10);
		vec.add(20);
		vec.add(30);
		vec.add(40);
		vec.add(50);
		vec.add(60);
		System.out.println("Vector:" + vec);
		System.out.println("Vector Size:" + vec.size());
		System.out.println("Vector Capacity:" + vec.capacity());
		vec.add(70);
		vec.add(80);
		System.out.println("Vector Updated Capacity:" + vec.capacity());
		Vector<Integer> vec2 = new Vector<Integer>(50);
		System.out.println("Vector2 Intial Capacity:" + vec2.capacity());
		Vector<Integer> vec3 = new Vector<Integer>(50, 10);
		System.out.println("Vector2 Intial Capacity:" + vec3.capacity());
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		vec3.add(20);
		System.out.println("Updated Vector2 Intial Capacity:" + vec3.capacity());

		System.out.println();
		System.out.println("-------------------------");
		System.out.println("For Loop:");

		for (Integer i : vec) {
			System.out.print(i + ",");
		}
		System.out.println();
		System.out.println("-------------------------");
		System.out.println("Iterator:");
		Iterator<Integer> iterator = vec.iterator();
		while (iterator.hasNext()) {
			System.out.print(iterator.next() + ",");
		}
		System.out.println();
		System.out.println("-------------------------");
		System.out.println("ListIterator:");
		ListIterator<Integer> listIterator = vec.listIterator();
		while (listIterator.hasNext()) {
			System.out.print(listIterator.next() + ",");
		}
		System.out.println();
		while (listIterator.hasPrevious()) {
			System.out.print(listIterator.previous() + ",");
		}
		System.out.println();
		System.out.println("-------------------------");
		System.out.println("Enumeration:");
		Enumeration<Integer> enumeration = vec.elements();
		while (enumeration.hasMoreElements()) {
			System.out.print(enumeration.nextElement() + ",");
		}
	}

}
