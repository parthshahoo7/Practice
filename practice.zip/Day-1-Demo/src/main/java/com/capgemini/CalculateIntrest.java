package com.capgemini;

public class CalculateIntrest {

	private double principle = 23000;
	private int years = 3;
	private float rateofIntrest = 3.35f;

	public double calculateSimpleIntrest() {
		return this.principle * this.years * this.rateofIntrest;
	}

	public double calculateSimpleIntrest(double principle) {
		System.out.println("one Argument Method:");
		return principle * this.years * this.rateofIntrest;
	}

	public double calculateSimpleIntrest(double principle, int year) {
		System.out.println("Tewo Arguments Method");
		return principle * years * this.rateofIntrest;
	}

	public double calculateSimpleIntrest(double principle, int year, float rateofIntrest) {
		System.out.println("Three Arguments Method");
		return principle * years * rateofIntrest;
	}
}
