package org.cap.wallet.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.cap.wallet.model.Account;
import org.cap.wallet.model.Account.AccountType;
import org.cap.wallet.model.User;

public class AccountDaoImpl implements IAccountDao {
	private ArrayList<Account> accounts = new ArrayList<Account>();

	private Connection getDBConnection() throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.jdbc.Driver");
		String url = "jdbc:mysql://localhost:3306/capg_wallet";

		Connection connection = DriverManager.getConnection(url, "root", "1234");

		return connection;
	}

	@Override
	public Account createAccount(Account account) {
		// TODO Auto-generated method stub
		try (Connection conn = getDBConnection();) {
			String sql = "insert into account(accounttype,opening_date,discription,balance,userid) values(?,?,?,?,?)";
			PreparedStatement preparedStatement = conn.prepareStatement(sql);
			preparedStatement.setString(1, account.getAccountType().toString());
			preparedStatement.setDate(2, Date.valueOf(account.getOpeningDate()));
			preparedStatement.setString(3, account.getDiscription());
			preparedStatement.setDouble(4, account.getBalance());
			preparedStatement.setInt(5, account.getUser().getUserId());

			int count = preparedStatement.executeUpdate();
			if (count > 0) {
				String sql2 = "select max(accountid) from account";
				PreparedStatement pst = conn.prepareStatement(sql2);
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					account.setAccountId(rs.getString("max(accountid)"));
				}
				return account;
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Account searchAccount(String id) {
		// TODO Auto-generated method stub
		Account account = null;
		try (Connection conn = getDBConnection()) {
			String sql = "select * from account where accountid=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, id);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				account = new Account();
				account.setAccountId(rs.getString("accountid"));
				if (rs.getString("accounttype").equals((AccountType.Checking).toString())) {
					account.setAccountType(AccountType.Checking);
				} else if (rs.getString("accounttype").equals((AccountType.Savings).toString())) {
					account.setAccountType(AccountType.Savings);
				}
				account.setBalance(rs.getDouble("balance"));
				account.setDiscription(rs.getString("discription"));
				account.setOpeningDate(rs.getDate("opening_date").toLocalDate());
				IUserDao userDao = new UserDaoImpl();
				User user = userDao.searchUser(rs.getString("userid"));
				account.setUser(user);
				account.setAccountId(rs.getString("accountid"));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return account;
	}

	@Override
	public Account updateAccount(Account account) {
		// TODO Auto-generated method stub
		try (Connection conn = getDBConnection()) {
			String sql = "update account set accounttype=?,opening_date=?,discription=?,balance=? where accountid=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, account.getAccountType().toString());
			pst.setDate(2, Date.valueOf(account.getOpeningDate()));
			pst.setString(3, account.getDiscription());
			pst.setDouble(4, account.getBalance());
			pst.setString(5, account.getAccountId());
			int count = pst.executeUpdate();
			if (count > 0) {
				return account;
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public int generateAccountId() {
		// TODO Auto-generated method stub
		int id = -1;
		try (Connection connection = getDBConnection()) {
			String sql = "insert into accountid_seq values(null)";
			PreparedStatement psPreparedStatement = connection.prepareStatement(sql);
			int count = psPreparedStatement.executeUpdate();
			if (count > 0) {
				String sql2 = "select max(id) from accountid_seq";
				PreparedStatement ps = connection.prepareStatement(sql2);
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					id = rs.getInt("max(id)");
				}
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return id;
	}

	@Override
	public List<Account> getAllAccounts(int id) {
		// TODO Auto-generated method stub
		List<Account> accounts = null;
		try (Connection conn = getDBConnection()) {
			String sql = "select * from account where userid=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			accounts = new ArrayList<Account>();
			while (rs.next()) {
				Account account = new Account();
				account.setAccountId(rs.getString("accountid"));
				if (rs.getString("accounttype").equals((AccountType.Checking).toString())) {
					account.setAccountType(AccountType.Checking);
				} else if (rs.getString("accounttype").equals((AccountType.Savings).toString())) {
					account.setAccountType(AccountType.Savings);
				}
				account.setBalance(rs.getDouble("balance"));
				account.setDiscription(rs.getString("discription"));
				account.setOpeningDate(rs.getDate("opening_date").toLocalDate());
				IUserDao userDao = new UserDaoImpl();
				User user = userDao.searchUser(rs.getString("userid"));
				account.setUser(user);
				account.setAccountId(rs.getString("accountid"));
				accounts.add(account);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return accounts;
	}

	@Override
	public List<Account> getAllusersAccounts(int id) {
		// TODO Auto-generated method stub
		List<Account> accounts = null;
		try (Connection conn = getDBConnection()) {
			String sql = "select * from account where userid!=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			accounts = new ArrayList<Account>();
			while (rs.next()) {
				Account account = new Account();
				account.setAccountId(rs.getString("accountid"));
				if (rs.getString("accounttype").equals((AccountType.Checking).toString())) {
					account.setAccountType(AccountType.Checking);
				} else if (rs.getString("accounttype").equals((AccountType.Savings).toString())) {
					account.setAccountType(AccountType.Savings);
				}
				account.setBalance(rs.getDouble("balance"));
				account.setDiscription(rs.getString("discription"));
				account.setOpeningDate(rs.getDate("opening_date").toLocalDate());
				IUserDao userDao = new UserDaoImpl();
				User user = userDao.searchUser(rs.getString("userid"));
				account.setUser(user);
				account.setAccountId(rs.getString("accountid"));
				accounts.add(account);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return accounts;
	}

}
