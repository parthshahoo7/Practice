package org.cap.jpa.boot;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.jpa.model.Customer;
import org.cap.jpa.model.Location;

public class BootClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Obtain EMF object from persistanceContext
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("capg");

		// emf Populates entity manager
		EntityManager entityManager = emf.createEntityManager();

		// get Transaction object to perform transactions
		EntityTransaction entityTransaction = entityManager.getTransaction();
		Customer customer = new Customer("Tom", "Jery", 2300, true, "ppp@absdc.com", LocalDateTime.now());
		Customer customer1 = new Customer("Tom", "Jery", 2300, true, "qqq@sdbbc.com", LocalDateTime.now());
		customer1.setLocation(Location.PA);
		customer1.getCustomers().add(customer);
		// Customer customer2 = new Customer();
//		customer2.setEmailId("cf@cf.com");

//		customer2.setfName("dsvsdvsd");
		entityTransaction.begin();
		entityManager.persist(customer);
		entityManager.persist(customer1);
		// entityManager.persist(customer2);
		entityTransaction.commit();
		entityManager.close();
	}

}
