package org.cap.controller;

import java.util.ArrayList;
import java.util.List;

import org.cap.dao.IEmployeeDao;
import org.cap.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MyController {
	@Autowired
	private IEmployeeDao employeeDao;
	private List<Employee> employees;
	private boolean flag = false;

	@RequestMapping("/searchEmployee")
	public String searchEmployee(@RequestParam("searchEmp") String empid) {
		int employeeId = Integer.parseInt(empid);
		Employee employee = employeeDao.findEmployee(employeeId);
		List<Employee> emps = new ArrayList<Employee>();
		emps.add(employee);
		employees = emps;
		flag = true;
		return "redirect:/";
	}

	@RequestMapping(value = "/saveemployeedata", method = RequestMethod.POST)
	public String SaveEmployeeDetails(@ModelAttribute("employee") Employee employee) {
		employeeDao.saveEmployee(employee);
		return "redirect:/";
	}

	@RequestMapping("/")
	public String getEmployeeRegistrationPage(ModelMap map) {
		System.out.println(getStates());
		map.put("employee", new Employee());
		map.put("cities", getCities());
		map.put("mystates", getStates());
		map.put("countries", getCountries());
		if (flag == true) {
			map.put("emps", employees);
			flag = false;
		} else {
			map.put("emps", employeeDao.getEmployees());

		}
		return "register";
	}

	private List<String> getCities() {
		List<String> cities = new ArrayList<String>();
		cities.add("Washington");
		cities.add("NewYork");
		cities.add("Bowie");
		cities.add("OldBridge");
		cities.add("Scranton");
		cities.add("Philadelphia");
		return cities;
	}

	private List<String> getStates() {
		List<String> states = new ArrayList<String>();
		states.add("DC");
		states.add("NY");
		states.add("MD");
		states.add("NJ");
		states.add("PA");
		return states;
	}

	private List<String> getCountries() {
		List<String> countries = new ArrayList<String>();
		countries.add("USA");
		countries.add("UK");
		countries.add("India");
		countries.add("Australia");
		countries.add("Germen");
		return countries;
	}

	@RequestMapping("/deleteEmployee/{empId}")
	public String deleteEmployeeDetails(@PathVariable("empId") Integer employeeId) {
		employeeDao.deleteEMployee(employeeId);
		return "redirect:/";
	}

}
