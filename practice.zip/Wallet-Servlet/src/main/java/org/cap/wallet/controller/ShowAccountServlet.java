package org.cap.wallet.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.wallet.model.Account;
import org.cap.wallet.model.User;
import org.cap.wallet.service.AccountServiceImpl;
import org.cap.wallet.service.IAccountService;

/**
 * Servlet implementation class ShowAccountServlet
 */
@WebServlet({ "/ShowAccountServlet", "/showAccount" })
public class ShowAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		IAccountService accountService = new AccountServiceImpl();
		List<Account> accounts = accountService.getAllAccount(user.getUserId());
		System.out.println(accounts);
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE html>\r\n" + "<html>\r\n" + "<head>\r\n" + "<meta charset=\"ISO-8859-1\">\r\n"
				+ "<title>Insert title here</title>\r\n" + "</head>\r\n" + "<body>\r\n"
				+ "	<form method=\"post\" action=\"transaction\">\r\n"
				+ "		<h1 align=\"center\">Transaction</h1>\r\n" + "		<hr>\r\n" + "		<table>\r\n"
				+ "			<tr>\r\n"
				+ "				<td><input type=\"radio\" name=\"transactiontype\" value=\"deposit\">Deposit</td>\r\n"
				+ "				<td><input type=\"radio\" name=\"transactiontype\" value=\"withdraw\">Withdraw</td>\r\n"
				+ "			</tr>\r\n" + "\r\n");
		out.println("<tr>\r\n" + "				<td>Choose Account:</td>\r\n");
		out.println("<td>Select Account:</td>\r\n" + "				<td><select name=\"accountID\">\r\n");
		for (Account acc : accounts) {
			out.println("<option value=" + acc.getAccountId() + ">" + acc.getAccountId() + "</option>\r\n");
		}

		out.println("</select> </td>" + "			</tr>\r\n" + "			<tr>\r\n"
				+ "				<td>Amount:</td>\r\n"
				+ "				<td><input type=\"text\" name=\"amount\"></td>\r\n" + "			</tr>\r\n"
				+ "			<tr>\r\n"
				+ "				<td><button type=\"submit\">Perform Transaction</button></td>\r\n"
				+ "				<td><button type=\"reset\">Clear</button></td>\r\n" + "			</tr>\r\n"
				+ "		</table>\r\n" + "	</form>\r\n" + "</body>\r\n" + "</html>");
	}
}
