package com.capgemini;

public class MainClass {

	private int[] oddarr = new int[10];
	private int[] evenarr = new int[10];
	private int n = 0, m = 0;

	public int[] getOddarr() {
		return oddarr;
	}

	public void setOddarr(int[] oddarr) {
		this.oddarr = oddarr;
	}

	public int[] getEvenarr() {
		return evenarr;
	}

	public void setEvenarr(int[] evenarr) {
		this.evenarr = evenarr;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] combinedArray = { 10, 9, 6, 78, 4, 5, 33, 77, 67 };
		MainClass myArray = new MainClass();
		myArray.partitionOddEvenArray(combinedArray);
		myArray.showpartitionedArrays();
	}

	public void partitionOddEvenArray(int[] array) {
		for (int i = 0; i < array.length; i++) {
			if ((array[i] % 2) == 0) {
				evenarr[n] = array[i];
				n++;
			} else {
				oddarr[m] = array[i];
				m++;
			}
		}
	}

	public void showpartitionedArrays() {
		System.out.println("Even Array:");
		for (int i = 0; i < evenarr.length; i++) {
			if (i < n) {
				System.out.print(evenarr[i] + ",");
			}
		}
		System.out.println();
		System.out.println("Odd Array:");
		for (int i = 0; i < oddarr.length; i++) {
			if (i < m) {
				System.out.print(oddarr[i] + ",");
			}
		}

	}

}
