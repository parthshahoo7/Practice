package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.Employee;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Repository("employeeDao")
public class EmployeeDaoImpl implements IEmployeeDao {

	@PersistenceContext
	private EntityManager entitymanager;

	@Override
	public void saveEmployee(Employee employee) {
		// TODO Auto-generated method stub
		entitymanager.persist(employee);
//		entitymanager.persist(employee.getAddress());
	}

	@Override
	public List<Employee> getEmployees() {
		// TODO Auto-generated method stub
		List<Employee> employees = entitymanager.createQuery("from Employee").getResultList();
		return employees;
	}

	@Override
	public void deleteEMployee(int employeeId) {
		// TODO Auto-generated method stub
		Employee employee = entitymanager.find(Employee.class, employeeId);
		entitymanager.remove(employee);
	}

	@Override
	public Employee findEmployee(int employeeId) {
		// TODO Auto-generated method stub
		return entitymanager.find(Employee.class, employeeId);
	}

}
