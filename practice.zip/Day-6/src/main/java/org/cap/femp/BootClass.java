package org.cap.femp;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class BootClass {
	public static void main(String[] args) {

		UserInteractions userInteractions = new UserInteractions();
		Scanner sc = new Scanner(System.in);

		File file = new File("employee.dat");
		try (FileOutputStream fout = new FileOutputStream(file, true);
				ObjectOutputStream out = new ObjectOutputStream(fout);
				FileInputStream fin = new FileInputStream(file);
				ObjectInputStream in = new ObjectInputStream(fin);

		) {
			String choice = null;
			do {
				int option = userInteractions.displayMenu();
				switch (option) {
				case 1:
					Employee employee = userInteractions.getEmployeeDetails();
					out.writeObject(employee);
					break;
				case 2:
					Employee employee2 = (Employee) in.readObject();
					while (employee2 != null) {
						System.out.println(employee2);
						employee2 = (Employee) in.readObject();
					}
					break;
				case 3:
					System.out.println("Enter Employee ID:");
					int id;
					id = sc.nextInt();
					boolean flag = false;
					Employee employee3 = (Employee) in.readObject();
					while (employee3 != null) {
						if (employee3.getEmployeeId() == id) {
							System.out.println(employee3);
							flag = true;
						}
						employee3 = (Employee) in.readObject();
					}
					if (!flag) {
						System.out.println("Sorry Not Found!");
					}
					break;
				case 4:
					System.exit(0);
				default:
					System.out.println("Sorry! Wrong Input! Try Again!");
				}
				System.out.println("Do you wish to continue?[y|n]");
				choice = sc.next();
			} while (choice.charAt(0) == 'y' || choice.charAt(0) == 'Y');
		} catch (FileNotFoundException | EOFException e) {

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
