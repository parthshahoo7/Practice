package com.cap.exercise;

public class Chat {
	private String message;
	private String temp;
	private static int flag = 0;

	public Chat(String message) {
		System.out.println(message);
	}

	synchronized public void questions(String message) {
		System.out.println("Message from Sender.");
		this.message = message;
		this.flag++;
		notifyAll();
		System.out.println(this.message);
	}

	synchronized public void answer(String message) {
		this.message = message;
		temp = this.message;
		while (this.flag <= 0) {
			System.out.println("I am Waiting for Sender.!!!!!");
			try {
				wait();
				this.message = temp;
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		this.flag--;
		System.out.println(this.message);
	}
}
