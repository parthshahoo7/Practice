package com.cap.threddemo;

public class SupportThread extends Thread {

	@Override
	public void run() {
		for (int i = 0; i < 10000; i++) {
			System.out.println("Support Thread:" + i);
		}
	}
}
