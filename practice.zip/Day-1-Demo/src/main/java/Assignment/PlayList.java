package Assignment;

public class PlayList {
	private String[] myPlayList;
	private int count = 0;
	private int leastPressedButton = 0;

	public String[] getMyPlayList() {
		return myPlayList;
	}

	public void setMyPlayList(String[] myPlayList) {
		this.myPlayList = myPlayList;
	}

	public void setPlayListSize(int size) {
		myPlayList = new String[size];
	}

	public int goToNextSong(int cureentPosition, String nextSong) {
		for (int i = 0; i < myPlayList.length; i++) {
			if (myPlayList[i].equalsIgnoreCase(nextSong)) {
				count = i;
			}
		}
		leastPressedButton = (myPlayList.length - count) + cureentPosition;
		return leastPressedButton;
	}

}
