package org.cap.employee;

import java.sql.Date;

public class Employee {
	private int employeeId;
	private String fname;
	private String lname;
	private double salary;
	private boolean isPermenant;
	private Date dateofJoining;

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(int employeeId, String fname, String lname, double salary, boolean isPermenant,
			Date dateofJoining) {
		super();
		this.employeeId = employeeId;
		this.fname = fname;
		this.lname = lname;
		this.salary = salary;
		this.isPermenant = isPermenant;
		this.dateofJoining = dateofJoining;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public boolean isPermenant() {
		return isPermenant;
	}

	public void setPermenant(boolean isPermenant) {
		this.isPermenant = isPermenant;
	}

	public Date getDateofJoining() {
		return dateofJoining;
	}

	public void setDateofJoining(Date dateofJoining) {
		this.dateofJoining = dateofJoining;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", fname=" + fname + ", lname=" + lname + ", salary=" + salary
				+ ", isPermenant=" + isPermenant + ", dateofJoining=" + dateofJoining + "]";
	}

}
