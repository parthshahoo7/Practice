package org.cap.wallet.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

import org.cap.wallet.model.Address;
import org.cap.wallet.model.User;

public class UserDaoImpl implements IUserDao {
	ArrayList<User> users = new ArrayList<User>();

	private Connection getDBConnection() throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.jdbc.Driver");
		String url = "jdbc:mysql://localhost:3306/capg_wallet";

		Connection connection = DriverManager.getConnection(url, "root", "1234");

		return connection;
	}

	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub

		try (Connection connection = getDBConnection();) {
			String sql = "insert into user(firstname,lastname,password,emailid,dateofbirth,ssn)"
					+ "values(?,?,?,?,?,?)";
			PreparedStatement pst = connection.prepareStatement(sql);
			pst.setString(1, user.getFirstName());
			pst.setString(2, user.getLastName());
			pst.setString(3, user.getPassword());
			pst.setString(4, user.getEmailId());
			pst.setDate(5, Date.valueOf(user.getDateOfBirth()));
			pst.setString(6, user.getSSN());

			int count = pst.executeUpdate();
			if (count > 0) {
				String getUserId = "select max(userid) from user";
				PreparedStatement pst1 = connection.prepareStatement(getUserId);
				ResultSet rs = pst1.executeQuery();
				if (rs.next()) {
					user.setUserId(rs.getInt(1));
				}
				String sql2 = "insert into address(house_Number,streetName,city,state,zipcode,country,user_id) "
						+ "values(?,?,?,?,?,?,?)";

				PreparedStatement pst3 = connection.prepareStatement(sql2);
				pst3.setInt(1, user.getAddress().getHouseNumber());
				pst3.setString(2, user.getAddress().getStreetName());
				pst3.setString(3, user.getAddress().getCity());
				pst3.setString(4, user.getAddress().getState());
				pst3.setInt(5, user.getAddress().getZipcode());
				pst3.setString(6, user.getAddress().getCountry());
				pst3.setInt(7, user.getUserId());

				int value = pst3.executeUpdate();
				if (value > 0)
					return user;
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public User searchUser(String userId) {
		// TODO Auto-generated method stub
		User matcheduser = null;
		try (Connection connection = getDBConnection();) {
			String sql = "select * from user where userid=?";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, userId);

			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				matcheduser = new User();
				matcheduser.setFirstName(rs.getString("firstname"));
				matcheduser.setLastName(rs.getString("lastname"));
				matcheduser.setPassword(rs.getString("password"));
				matcheduser.setEmailId(rs.getString("emailid"));
				matcheduser.setDateOfBirth(rs.getDate("dateofbirth").toLocalDate());
				matcheduser.setSSN(rs.getString("ssn"));
				matcheduser.setUserId(rs.getInt("userid"));
			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return matcheduser;
	}

	@Override
	public User loginUser(String emailid, String password) {
		// TODO Auto-generated method stub
		User user = null;
		try (Connection connection = getDBConnection();) {
			String sql = "select * from user where emailid=? and password=?";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, emailid);
			preparedStatement.setString(2, password);

			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				user = new User();
				user.setUserId(resultSet.getInt("userid"));
				user.setFirstName(resultSet.getString("firstname"));
				user.setLastName(resultSet.getString("lastname"));
				user.setPassword(resultSet.getString("password"));
				user.setDateOfBirth(resultSet.getDate("dateofbirth").toLocalDate());
				user.setSSN(resultSet.getString("ssn"));
				user.setEmailId(resultSet.getString("emailid"));
			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}

}
