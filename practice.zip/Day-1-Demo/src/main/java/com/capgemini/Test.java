package com.capgemini;

public class Test {

	public static void main(String[] args) {
		CalculateIntrest ci = new CalculateIntrest();
		System.out.println(ci.calculateSimpleIntrest());
		double intrest = ci.calculateSimpleIntrest(5000);
		System.out.println("Intrest:" + intrest);
	}
}
