package com.capg.abstractDemo;

public class Circle extends Shape {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("Draw Circle!!!");

	}

}
