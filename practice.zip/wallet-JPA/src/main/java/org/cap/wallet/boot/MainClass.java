package org.cap.wallet.boot;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.wallet.model.Address;
import org.cap.wallet.model.User;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("wallet");
		EntityManager entityManager = emf.createEntityManager();

		EntityTransaction entityTransaction = entityManager.getTransaction();

		Address address = new Address(123, "dcdc", "USA", "cscd", "cdcds", 12312);
		User user = new User("csd", "cdac", address, "Apple@123", null, "q@q.com", LocalDate.now(), "123-12-1231");

		entityTransaction.begin();
		entityManager.persist(user);
		entityManager.persist(address);
		entityTransaction.commit();
		entityManager.close();
		emf.close();

	}

}
