package org.cap.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class LoginController {

	@PostMapping("/login")
	public String validateUserLogin(@RequestParam("userName") String userName,
			@RequestParam("userPassword") String userPassword) {
		if (userName.equalsIgnoreCase("tom") && userPassword.equalsIgnoreCase("tom123")) {
			return "success";
		} else {
			return "redirect:/";
		}
	}
}
