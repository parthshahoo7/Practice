package com.cap.exercise;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final Chat chat = new Chat("");
		Thread sender1 = new Thread() {
			@Override
			public void run() {
				chat.questions("Hey How Are You?");
			}
		};
		sender1.start();
		Thread sender2 = new Thread() {
			@Override
			public void run() {
				chat.questions("I am also fine. Wanna go for movie?");
			}
		};
		sender2.start();
		Thread receiver = new Thread() {
			@Override
			public void run() {
				chat.answer("I am Fine. What about you?");
			}
		};
		receiver.start();
		Thread receiver2 = new Thread() {
			@Override
			public void run() {
				chat.answer("yeah Sure.");
			}
		};
		receiver2.start();
		Thread receiver3 = new Thread() {
			@Override
			public void run() {
				chat.answer("Ok!");
			}
		};
		receiver3.start();
		Thread sender3 = new Thread() {
			@Override
			public void run() {
				chat.questions("8 p.m?");
			}
		};
		sender3.start();
	}

}
