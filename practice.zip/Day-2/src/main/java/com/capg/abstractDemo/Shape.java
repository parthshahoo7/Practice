package com.capg.abstractDemo;

public abstract class Shape {

	private int pointA;
	private int pointB;

	public int getPointA() {
		return pointA;
	}

	public void setPointA(int pointA) {
		this.pointA = pointA;
	}

	public int getPointB() {
		return pointB;
	}

	public void setPointB(int pointB) {
		this.pointB = pointB;
	}

	public Shape() {
		System.out.println("Shape Class Constructor!");
	}

	public abstract void draw();

	public static int calculate(int a, int b) {
		return 0;
	}

}
