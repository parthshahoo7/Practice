package com.capg;

public class Utility {

	public static boolean isValidEmployeeID(String employeeID) {
		return employeeID.matches("\\d{5}_[F|T]S");

	}

	public static boolean isValidEmployeeFirstName(String firstName) {
		return firstName.matches("[A-Z][a-zA-Z]+");
	}

	@SuppressWarnings("finally")
	public static boolean isValidEmployeeSalary(Double salary) {
		// TODO Auto-generated method stub
		double min = 2000;
		double max = 10000;
		boolean flag = false;
		if (min < salary && salary <= max) {
			flag = true;
			return flag;
		} else {
			try {
				throw new CustomExceptionClass();
			} catch (CustomExceptionClass e) {

				System.out.println(e);
				e.printStackTrace();
			} finally {
				return flag;
			}
		}
	}

	public static boolean isValidEmployeeEmailID(String emailId) {
		// TODO Auto-generated method stub
		return emailId.matches("^(.+)@(.+)$");
	}
}
