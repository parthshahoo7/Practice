package com.cap.threddemo;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Main ID:" + Thread.currentThread().getId());
		PrintTable table = new PrintTable(5);
		Thread t1 = new Thread(table);
		try {
			Thread.sleep(1000, 100);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
//		t1.setPriority(Thread.MAX_PRIORITY);
		t1.start();
//		t1.start(); --> Throws Illigal Thread State Exception
		// t1.run();
		PrintTable table2 = new PrintTable(13);
		Thread t2 = new Thread(table2);
		t2.start();
		try {
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PrintTable table3 = new PrintTable(15);
		Thread t3 = new Thread(table2);
		t3.setPriority(Thread.MIN_PRIORITY);
		t3.start();

		// Anonymus Thread
//		Runnable target = new Runnable() {
//
//			@Override
//			public void run() {
//				// TODO Auto-generated method stub
//				for (int i = 1; i <= 10; i++) {
//					System.out.println(i + "*5=" + (i * 5) + Thread.currentThread().getName());
//				}
//			}
//		};
//		Thread annt1=new Thread(target);
//		annt1.start();

		// Using Runnable Interface

		/*
		 * MyRunnableThread runnableThread = new MyRunnableThread(); Thread t1 = new
		 * Thread(runnableThread); t1.start(); Thread t2 = new Thread(runnableThread);
		 * t2.start(); Thread t3 = new Thread(runnableThread, "ThridThread");
		 * t3.start();
		 */

		// Using Extening Thread Class
		/*
		 * System.out.println(Thread.currentThread().getName()); MyThread t1 = new
		 * MyThread("My 1st Thread"); t1.start(); MyThread t2 = new MyThread();
		 * t2.start();
		 */
	}
}