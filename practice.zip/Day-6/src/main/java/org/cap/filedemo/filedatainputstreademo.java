package org.cap.filedemo;

public class filedatainputstreademo {
	private int employeeid;
	private String name;
	private char gender;
	private double salary;
	private int lengthofname;

	public int getLengthofname() {
		return lengthofname;
	}

	public void setLengthofname(int lengthofname) {
		this.lengthofname = lengthofname;
	}

	public int getEmployeeid() {
		return employeeid;
	}

	public void setEmployeeid(int employeeid) {
		this.employeeid = employeeid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char string) {
		this.gender = string;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "filedatainputstreademo [employeeid=" + employeeid + ", name=" + name + ", gender=" + gender
				+ ", salary=" + salary + ", lengthofname=" + lengthofname + "]";
	}
	

}
