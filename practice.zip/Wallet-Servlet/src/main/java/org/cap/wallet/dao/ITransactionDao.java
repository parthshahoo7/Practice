package org.cap.wallet.dao;

import java.sql.Date;
import java.util.List;

import org.cap.wallet.model.Transactions;

public interface ITransactionDao {

	public Transactions addTransaction(Transactions transaction);

	public List<Transactions> viewAllTransactions(String accountid);

	public List<Transactions> viewAllTransactions(String accountid, Date fromDate, Date toDate);

}
