package org.cap.demo.dao;

import org.cap.demo.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("employeeDbDao")
@Transactional
public interface IDBEmployeeDao extends JpaRepository<Employee, Integer> {

}
