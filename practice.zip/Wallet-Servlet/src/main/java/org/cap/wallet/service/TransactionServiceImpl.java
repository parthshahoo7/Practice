package org.cap.wallet.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.cap.wallet.dao.ITransactionDao;
import org.cap.wallet.dao.TransactionDaoImpl;
import org.cap.wallet.model.Transactions;

public class TransactionServiceImpl implements ITransactionService {

	private ITransactionDao transactionDao = new TransactionDaoImpl();

	@Override
	public Transactions addTransaction(Transactions transaction) {
		return transactionDao.addTransaction(transaction);

	}

	@Override
	public List<Transactions> viewAllTransactions(String accountid) {
		// TODO Auto-generated method stub
		return transactionDao.viewAllTransactions(accountid);
	}

	@Override
	public List<Transactions> viewAllTransactions(String accountid, Date fromDate, Date toDate) {
		// TODO Auto-generated method stub
		return transactionDao.viewAllTransactions(accountid, fromDate, toDate);
	}

}
