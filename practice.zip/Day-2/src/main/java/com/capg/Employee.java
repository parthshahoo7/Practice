package com.capg;

public class Employee {

	public enum EmployeeType {
		Permenent, Parttime, Contract;
	}

	private String employeeId;
	private String firstName;
	private String lastName;
	private double salary;
	private String emailId;
	private EmployeeType employeeType;
	private Address address;

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public EmployeeType getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(EmployeeType employeeType) {
		this.employeeType = employeeType;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Employee(String employeeId, String firstName, String lastName, double salary, String emailId) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.emailId = emailId;
	}

	public Employee(String employeeId, String firstName, String lastName, double salary) {
		// super(); you can call this in following callable constructor
		this(employeeId, firstName); // this must be a first line
		// this(); you can't call multiple keywords.
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
	}

	public Employee(String employeeId, String firstName) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", salary=" + salary + ", emailId=" + emailId + ", employeeType=" + employeeType + "]";
	}
}
