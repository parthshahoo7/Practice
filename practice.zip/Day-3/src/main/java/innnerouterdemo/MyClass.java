package innnerouterdemo;

import java.sql.Array;
import java.util.Arrays;
import java.util.Scanner;

public class MyClass {
	public static void main(String[] args) {

		String str = null;
		String s = null;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first Name:");
		str = sc.next();
		System.out.println("Enter the second Name:");
		s = sc.next();
		char a[] = str.toCharArray();
		char b[] = s.toCharArray();
		Arrays.sort(a);
		Arrays.sort(b);
		str = new String(a);
		s = new String(b);
		System.out.println(str);
		System.out.println(s);
		if (s.equals(str)) {
			System.out.println("matched! String is Anagram.");
		}
	}
	/*
	 * for (int i = 0; i < str.length(); i++) { a[i] = s.charAt(i); for (int j = 0;
	 * j < str.length() - 1; j++) { if (((int) s.charAt(i)) > ((int) s.charAt(j))) {
	 * a[i] = s.charAt(j); } } } for (int i = 0; i < a.length; i++) {
	 * System.out.println(a[i]); }
	 */

//		System.out.println(str == s);
//		try {
//			f();
//		} catch (InterruptedException e) {
//			System.out.println("1");
//			throw new RuntimeException();
//		} catch (RuntimeException e) {
//			System.out.println("2");
//			return;
//		} catch (Exception e) {
//			System.out.println("3");
//		} finally {
//			System.out.println("4");
//		}
//		System.out.println("5");
//	}

// InterruptedException is a direct subclass of Exception.
	static void f() throws InterruptedException {
		throw new InterruptedException("Time for lunch.");
	}
}
