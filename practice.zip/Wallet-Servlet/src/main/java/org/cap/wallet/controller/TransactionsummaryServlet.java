package org.cap.wallet.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.wallet.model.Account;
import org.cap.wallet.model.Transactions;
import org.cap.wallet.model.User;
import org.cap.wallet.service.AccountServiceImpl;
import org.cap.wallet.service.IAccountService;
import org.cap.wallet.service.ITransactionService;
import org.cap.wallet.service.TransactionServiceImpl;

/**
 * Servlet implementation class TransactionsummaryServlet
 */
@WebServlet({ "/TransactionsummaryServlet", "/transactionsummary" })
public class TransactionsummaryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		IAccountService accountService = new AccountServiceImpl();
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		List<Account> accounts = accountService.getAllAccount(user.getUserId());
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE html>\r\n" + "<html>\r\n" + "<head>\r\n" + "<meta charset=\"ISO-8859-1\">\r\n"
				+ "<title>Insert title here</title>\r\n"
				+ "<link href=\"css/bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\">\r\n" + "\r\n"
				+ "<!-- Custom styles for this template -->\r\n"
				+ "<link href=\"css/full-width-pics.css\" rel=\"stylesheet\">\r\n" + "\r\n"
				+ "<!-- Css For Login  -->\r\n" + "\r\n" + "\r\n" + "\r\n" + "\r\n" + "\r\n"
				+ "<link rel=\"stylesheet\"\r\n"
				+ "	href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\">\r\n"
				+ "<script\r\n"
				+ "	src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js\"></script>\r\n"
				+ "<script\r\n"
				+ "	src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>\r\n"
				+ "</head>\r\n" + "<!-- Navigation -->\r\n"
				+ "	<nav class=\"navbar navbar-expand-lg navbar-dark bg-dark fixed-top\">\r\n"
				+ "		<div class=\"container\">\r\n"
				+ "			<a class=\"navbar-brand\" href=\"pages/home.html\">Capg-Wallet</a>\r\n"
				+ "			<button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\"\r\n"
				+ "				data-target=\"#navbarResponsive\" aria-controls=\"navbarResponsive\"\r\n"
				+ "				aria-expanded=\"false\" aria-label=\"Toggle navigation\">\r\n"
				+ "				<span class=\"navbar-toggler-icon\"></span>\r\n" + "			</button>\r\n"
				+ "			<div class=\"collapse navbar-collapse\" id=\"navbarResponsive\">\r\n"
				+ "				<ul class=\"navbar-nav ml-auto\">\r\n"
				+ "					<li class=\"nav-item active\"><a class=\"nav-link\"\r\n"
				+ "						href=\"pages/home.html\">Home <span class=\"sr-only\">(current)</span>\r\n"
				+ "					</a></li>\r\n"
				+ "					<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
				+ "						href=\"pages/registeraccount.html\">Create Account</a></li>\r\n"
				+ "					<li class=\"nav-item\"><a class=\"nav-link\" href=\"transaction\">Transaction</a></li>\r\n"
				+ "					<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
				+ "						href=\"checkbalance\">Check Balance</a></li>\r\n"
				+ "					<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
				+ "						href=\"fundtransfer\">FundTransfer</a></li>\r\n"
				+ "					<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
				+ "						href=\"transactionsummary\">Transaction Summary</a></li>\r\n"
				+ "					<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
				+ "						href=\"LogoutServlet\">Logout</a></li>\r\n" + "				</ul>\r\n"
				+ "			</div>\r\n" + "		</div>\r\n" + "	</nav>\r\n"
				+ "	<!-- Header - set the background image for the header in the line below -->" + "<body>\r\n"
				+ "	<form method=\"post\" action=\"transactionsummary\">\r\n"
				+ "		<h1 align=\"center\">Transaction Summary</h1>\r\n" + "		<hr>\r\n" + "		<table>\r\n"
				+ "			<tr>\r\n" + "				<td>Choose Account:</td>\r\n"
				+ "				<td><div class=\"form-group\"><select name=\"accountid\">");
		for (Account acc : accounts) {
			out.println("<option value=" + acc.getAccountId() + ">" + acc.getAccountId() + "</option>\\r\\n");
		}
		out.println("</select></div></td>\r\n"

				+ "			</tr>\r\n" + "			<tr>\r\n" + "				<td>From Date:</td>\r\n"
				+ "				<td><div class=\"form-group\"><input type=\"date\" class=\"form-control\" name=\"fromdate\"></div></td>\r\n"
				+ "				<td>To Date:</td>\r\n"
				+ "				<td><div class=\"form-group\"><input type=\"date\" class=\"form-control\" name=\"todate\"></div></td>\r\n"
				+ "			</tr>\r\n" + "			<tr>\r\n"
				+ "				<td><div class=\"form-group\"><button type=\"submit\" class=\"btn btn-primary btn-lg btn-block \">Display</button></iv></td>\r\n"
				+ "				<td><div class=\"form-group\"><button type=\"reset\" class=\"btn btn-primary \">Clear</button></div></td>\r\n"
				+ "			</tr>\r\n" + "		</table>\r\n" + "	</form>\r\n" + "</body>\r\n" + "</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		IAccountService accountService = new AccountServiceImpl();
		Account account;
		// HttpSession session = request.getSession();
		ITransactionService transactionService = new TransactionServiceImpl();
		String accountId = request.getParameter("accountid");
		Date fromDate = Date.valueOf(request.getParameter("fromdate"));
		Date toDate = Date.valueOf(request.getParameter("todate"));
		List<Transactions> transactions = transactionService.viewAllTransactions(accountId, fromDate, toDate);
		PrintWriter out = response.getWriter();
		// User user = (User) session.getAttribute("user");
		// List<Account> accounts = accountService.getAllAccount(user.getUserId());
		doGet(request, response);
		if (!transactions.isEmpty()) {
			out.println("<br/>");
			out.println("<h1>Transaction Details</h1");
			out.println("<hr/>");
			out.println("<table  class=\"table table-hover\">\r\n" + "		<tr>\r\n"
					+ "			<th>Transaction Type</th>\r\n" + "			<th>Transaction Date</th>\r\n"
					+ "			<th>Amount</th>\r\n" + "			<th>Description</th>\r\n"
					+ "			<th>FromAccount</th>\r\n" + "			<th>ToAccount</th>\r\n" + "		</tr>\r\n");
			for (Transactions transaction : transactions) {
				out.println("		<tr>\r\n");
				out.println("<td>" + transaction.getTransactionType() + "</td>\r\n");
				out.println("<td>" + transaction.getTransactionDate() + "</td>\r\n");
				out.println("<td>" + transaction.getAmount() + "</td>\r\n");
				out.println("<td>" + transaction.getDescription() + "</td>\r\n");
				out.println("<td>" + transaction.getFromAccountId() + "</td>\r\n");
				out.println("<td>" + transaction.getToAccountId() + "</td>\r\n");
				out.println("	</tr>\r\n");

			}
			out.println("</table>");
		}

	}

}
