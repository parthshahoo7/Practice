package org.cap.wallet.dao;

import java.util.List;

import org.cap.wallet.model.Transactions;

public interface ITransactionDao {

	public Transactions addTransaction(Transactions transaction);

	public List<Transactions> viewAllTransactions(String accountid);

}
