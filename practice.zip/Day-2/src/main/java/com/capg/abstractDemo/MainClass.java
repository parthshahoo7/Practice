package com.capg.abstractDemo;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape circle = new Circle();
		circle.draw();

		Shape triangle = new Triangle();
		triangle.draw();
		Shape shape = new Shape() {

			@Override
			public void draw() {
				// TODO Auto-generated method stub
				System.out.println("This is my inner draw Class!");
			}
		};

		shape.draw();
		shape.draw();

	}

}
