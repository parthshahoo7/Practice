
package hooks;

import org.junit.After;
import org.junit.Before;

public class CalculatorHooks {

	@Before
	public void beforeScenario() {
		System.out.println("This will run before scenario");
	}

	@After
	public void afterScenario() {
		System.out.println("This will run after scenario");
	}
}
