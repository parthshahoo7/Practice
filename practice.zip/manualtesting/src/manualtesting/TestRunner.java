package manualtesting;

import org.junit.Test;

public class TestRunner {

	@Test
	public void testFindMaxArray() {

	}

}
