package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.IDBEmployeeDao;
import org.cap.demo.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("employeeDBService")
public class DBEMployeeServiceImpl implements IDbEmployeeService {
	@Autowired
	private IDBEmployeeDao employeeDbDao;

	@Override
	public List<Employee> getAllEmployee() {

		return employeeDbDao.findAll();
	}

	@Override
	public Employee findEmployee(Integer empID) {

		return employeeDbDao.getOne(empID);
	}

	@Override
	public List<Employee> deleteEmployee(Integer empId) {
		employeeDbDao.deleteById(empId);
		return employeeDbDao.findAll();
	}

	@Override
	public List<Employee> createEmployee(Employee employee) {
		employeeDbDao.save(employee);
		return employeeDbDao.findAll();
	}

	@Override
	public List<Employee> updateEmployee(Employee employee) {
		return createEmployee(employee);
	}

	@Override
	public List<Employee> updateEmployeeFirstName(Integer empId, String firstName) {

		Employee employee = findEmployee(empId);
		employee.setFirstName(firstName);
		return employeeDbDao.findAll();
	}

}
