package com.capg.collection;

import java.util.HashSet;
import java.util.Iterator;

public class SetDemo {

	public static void main(String[] args) {
		HashSet<Integer> hashSet = new HashSet<Integer>();
		hashSet.add(23);
		hashSet.add(24);
		hashSet.add(26);
		hashSet.add(45);
		hashSet.add(20);
		hashSet.add(24);
		hashSet.add(24);
		hashSet.add(null);
		System.out.println(hashSet.toString());
		System.out.println("--------------");
		System.out.println("For Loop");
		for (Integer i : hashSet) {
			System.out.print(i + ",");
		}
		System.out.println();
		System.out.println("------------------");
		System.out.println("Iterator:");
		Iterator<Integer> iterator = hashSet.iterator();
		while (iterator.hasNext()) {
			System.out.print(iterator.next() + ",");
		}
	}

}
