package org.cap.wallet.dao;

import org.cap.wallet.model.User;

public interface IUserDao {

	public User addUser(User user);

	public User searchUser(String userId);

	public User loginUser(String userId, String password);
};
